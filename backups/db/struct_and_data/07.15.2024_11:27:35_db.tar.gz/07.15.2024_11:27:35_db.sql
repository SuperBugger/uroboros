--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bdu; Type: SCHEMA; Schema: -; Owner: owner
--

CREATE SCHEMA bdu;


ALTER SCHEMA bdu OWNER TO owner;

--
-- Name: debtracker; Type: SCHEMA; Schema: -; Owner: owner
--

CREATE SCHEMA debtracker;


ALTER SCHEMA debtracker OWNER TO owner;

--
-- Name: maintenance; Type: SCHEMA; Schema: -; Owner: owner
--

CREATE SCHEMA maintenance;


ALTER SCHEMA maintenance OWNER TO owner;

--
-- Name: repositories; Type: SCHEMA; Schema: -; Owner: owner
--

CREATE SCHEMA repositories;


ALTER SCHEMA repositories OWNER TO owner;

--
-- Name: compare_assm(integer); Type: PROCEDURE; Schema: maintenance; Owner: owner
--

CREATE PROCEDURE maintenance.compare_assm(IN a_id integer)
    LANGUAGE plpgsql
    AS $$
declare
date_created timestamptz;
proj_id integer;
start_date timestamptz;
	begin

		select prj_id into proj_id
		from repositories.assembly a
		where assm_id = a_id;

		select assm_date_created into date_created
		from repositories.assembly a
		where assm_id = a_id;

		insert into maintenance.compare_assm
		(pkg_name, curr_vers, curr_date, vers_status,
		assm_date, pkg_vers, prev, current_assm)
		select CASE
		when l.now_pkg is NULL
			THEN l.old_pkg
			ELSE l.now_pkg
		end as pkg_name,
		l.vers, l.assm, l.st as text, l.date_prev, l.max_prev, false, true
		from (
			select aa.pkg_name as old_pkg, s.pkg_name as now_pkg, aa.vers, aa.assm,
			CASE
				WHEN aa.vers>s.max_prev THEN 'повышен'
			    WHEN aa.vers<s.max_prev THEN 'понижен'
				WHEN aa.vers=s.max_prev THEN 'неизменен'
				WHEN aa.vers is NULL THEN 'удален'
				ELSE 'добавлен'
		    end as st,
		    s.date_prev, s.max_prev
		    from (
				select p.pkg_name, max(pv."version") as vers, max(a.assm_date_created) as assm
				from repositories.pkg_version pv
				join repositories.assm_pkg_vrs apv on apv.pkg_vrs_id = pv.pkg_vrs_id
				join repositories.assembly a on a.assm_id = apv.assm_id
				join repositories.package p on p.pkg_id = pv.pkg_id
				where assm_date_created  = date_created
				group by p.pkg_name) as aa
			full join (
				select e.pkg_name, max(e.assm_date_created) as date_prev, max(e."version") as max_prev
				from (
					select rp.pkg_name, a2.assm_date_created, pv3."version"
					from repositories.package rp
					join repositories.pkg_version pv3 on pv3.pkg_id = rp.pkg_id
					join repositories.assm_pkg_vrs apv2 on apv2.pkg_vrs_id = pv3.pkg_vrs_id
					join repositories.assembly a2 on a2.assm_id = apv2.assm_id
					where a2.assm_date_created < date_created and prj_id=proj_id) as e
					group by e.pkg_name
						) as s on s.pkg_name = aa.pkg_name
					) as l
			order by pkg_name;

		select assm_date_created into start_date
		from repositories.assembly
		where assm_date_created < date_created::timestamptz
		and prj_id = proj_id
		order by assm_date_created desc
		limit 1;

		insert into maintenance.compare_assm
		(pkg_name, curr_vers, curr_date, vers_status,
		assm_date, pkg_vers, prev, current_assm)
		select CASE
				when l.now_pkg is NULL
					THEN l.old_pkg
					ELSE l.now_pkg
		       		end as pkg_name,
		l.vers, l.assm, l.st as text, l.date_prev, l.max_prev, true, false
		from (
			select aa.pkg_name as old_pkg, s.pkg_name as now_pkg, aa.vers, aa.assm,
			CASE
				WHEN aa.vers>s.max_prev THEN 'повышен'
			    WHEN aa.vers<s.max_prev THEN 'понижен'
	            WHEN aa.vers=s.max_prev THEN 'неизменен'
	            WHEN aa.vers is NULL THEN 'удален' 
	            ELSE 'добавлен'
		   	end as st,
		    s.date_prev, s.max_prev from (
				select p.pkg_name, max(pv."version") as vers, max(a.assm_date_created) as assm
				from repositories.pkg_version pv
				join repositories.assm_pkg_vrs apv on apv.pkg_vrs_id = pv.pkg_vrs_id
				join repositories.assembly a on a.assm_id = apv.assm_id
				join repositories.package p on p.pkg_id = pv.pkg_id
				where assm_date_created  = start_date
				group by p.pkg_name) as aa
			full join (
				select e.pkg_name, max(e.assm_date_created) as date_prev, max(e."version") as max_prev from
					(select rp.pkg_name, a2.assm_date_created, pv3."version"
					from repositories.package rp
					join repositories.pkg_version pv3 on pv3.pkg_id = rp.pkg_id
					join repositories.assm_pkg_vrs apv2 on apv2.pkg_vrs_id = pv3.pkg_vrs_id
					join repositories.assembly a2 on a2.assm_id = apv2.assm_id
					where a2.assm_date_created < start_date and prj_id=proj_id) as e
					group by e.pkg_name
					) as s on s.pkg_name = aa.pkg_name
				) as l
			order by pkg_name;


		select assm_date_created into start_date
		from repositories.assembly
		where assm_date_created < date_created::timestamptz
		and prj_id = proj_id
		order by assm_date_created desc
		limit 1;

		insert into maintenance.compare_assm
		(pkg_name, curr_vers, curr_date, vers_status, assm_date, pkg_vers, prev, current_assm)
		select CASE
			when l.now_pkg is NULL THEN l.old_pkg
			ELSE l.now_pkg
		end as pkg_name,
		l.vers, l.assm, l.st as text, l.date_prev, l.max_prev, true, true
		from (
			select aa.pkg_name as old_pkg, s.pkg_name as now_pkg, aa.vers, aa.assm,
			CASE
				WHEN aa.vers>s.max_prev THEN 'повышен'
		   		WHEN aa.vers<s.max_prev THEN 'понижен'
		        WHEN aa.vers=s.max_prev THEN 'неизменен'
	            WHEN aa.vers is NULL THEN 'удален'
		        ELSE 'добавлен'
		   	end as st,
		    s.date_prev, s.max_prev  from (
				select p.pkg_name, max(pv."version") as vers, max(a.assm_date_created) as assm
				from repositories.pkg_version pv
				join repositories.assm_pkg_vrs apv on apv.pkg_vrs_id = pv.pkg_vrs_id
				join repositories.assembly a on a.assm_id = apv.assm_id
				join repositories.package p on p.pkg_id = pv.pkg_id
				where assm_date_created  = date_created
				group by p.pkg_name) as aa
			full join (
				select e.pkg_name, max(e.assm_date_created) as date_prev, max(e."version") as max_prev from
					(select rp.pkg_name, a2.assm_date_created, pv3."version"
					from repositories.package rp
					join repositories.pkg_version pv3 on pv3.pkg_id = rp.pkg_id
					join repositories.assm_pkg_vrs apv2 on apv2.pkg_vrs_id = pv3.pkg_vrs_id
					join repositories.assembly a2 on a2.assm_id = apv2.assm_id
					where a2.assm_date_created = start_date and prj_id=proj_id) as e
					group by e.pkg_name
					) as s on s.pkg_name = aa.pkg_name
				) as l
			order by pkg_name;
		
		select assm_date_created into start_date
		from repositories.assembly
		where assm_date_created < date_created::timestamptz
		and prj_id = proj_id
		order by assm_date_created desc
		limit 1;


	END;


$$;


ALTER PROCEDURE maintenance.compare_assm(IN a_id integer) OWNER TO owner;

--
-- Name: get_assm_cve(boolean, integer); Type: FUNCTION; Schema: maintenance; Owner: owner
--

CREATE FUNCTION maintenance.get_assm_cve(resolved boolean, asm_id integer) RETURNS TABLE(pkg_name text, asm_version text, pkg_version text, cve_name text, cve_desc text, st_name text, urg_name text, rep_name text, link text, vul_ident text, vul_name text, vul_desc text, date_discovered timestamp with time zone, cvss2_vector text, cvss2_score text, cvss3_vector text, cvss3_score text, severity text, cwe_name text, url text)
    LANGUAGE plpgsql ROWS 10000
    AS $$
	begin
		if resolved = false then
		return query (select pkg_assm.pkg_name, dpv."version", pkg_assm."version", dc.cve_name, dc.cve_desc,
         ds.st_name, du.urg_name, dr.rep_name, bi.link, bv.vul_ident, bv.vul_name, bv.vul_desc, bv.date_discovered, bv.cvss2_vector,
		bv.cvss2_score, bv.cvss3_vector, bv.cvss3_score, bv.severity, bc.cwe_name, bvs.url from
		(select rp.pkg_name, pv2."version" from repositories.assembly a
		join repositories.assm_pkg_vrs apv on apv.assm_id = a.assm_id
		join repositories.pkg_version pv2 on pv2.pkg_vrs_id = apv.pkg_vrs_id
		join repositories.package rp on rp.pkg_id=pv2.pkg_id
		where a.assm_id = asm_id
		) as pkg_assm
		join debtracker.package dp on pkg_assm.pkg_name = dp.pkg_name
		join debtracker.pkg_version dpv on dp.pkg_id=dpv.pkg_id
		join debtracker.cve_rep dcr on dpv.pkg_vrs_id = dcr.fixed_pkg_vrs_id
		join debtracker.cve dc on dc.cve_id = dcr.cve_id
		join debtracker.repository dr on dr.rep_id=dcr.rep_id
		join debtracker.urgency du on du.urg_id=dcr.urg_id
		join debtracker.status ds on ds.st_id=dcr.st_id
		left join bdu.identifier bi on bi.ident_name = dc.cve_name
		left join bdu.vul_ident bvi on bvi.ident_id = bi.ident_id
		left join bdu.vulnerability bv on bv.vul_id = bvi.vul_id
		left join bdu.vul_sources bvs on bvs.vul_id = bv.vul_id
		left join bdu.vul_cwe bvc on bvc.vul_id = bv.vul_id
		left join bdu.cwe bc on bc.cwe_id = bvc.cwe_id
		where pkg_assm."version">=dpv."version");
		end if;

		if resolved = true then
		return query (select pkg_assm.pkg_name, dpv."version", pkg_assm."version", dc.cve_name, dc.cve_desc,
         ds.st_name, du.urg_name, dr.rep_name,  bi.link, bv.vul_ident, bv.vul_name, bv.vul_desc, bv.date_discovered, bv.cvss2_vector,
		bv.cvss2_score, bv.cvss3_vector, bv.cvss3_score, bv.severity, bc.cwe_name, bvs.url from
		(select rp.pkg_name, pv2."version" from repositories.assembly a
		join repositories.assm_pkg_vrs apv on apv.assm_id = a.assm_id
		join repositories.pkg_version pv2 on pv2.pkg_vrs_id = apv.pkg_vrs_id
		join repositories.package rp on rp.pkg_id=pv2.pkg_id
		where a.assm_id = asm_id
		) as pkg_assm
		join debtracker.package dp on pkg_assm.pkg_name = dp.pkg_name
		join debtracker.pkg_version dpv on dp.pkg_id=dpv.pkg_id
		join debtracker.cve_rep dcr on dpv.pkg_vrs_id = dcr.pkg_resolved_id
		join debtracker.cve dc on dc.cve_id = dcr.cve_id
		join debtracker.repository dr on dr.rep_id=dcr.rep_id
		join debtracker.urgency du on du.urg_id=dcr.urg_id
		join debtracker.status ds on ds.st_id=dcr.st_id
		left join bdu.identifier bi on bi.ident_name = dc.cve_name
		left join bdu.vul_ident bvi on bvi.ident_id = bi.ident_id
		left join bdu.vulnerability bv on bv.vul_id = bvi.vul_id
		left join bdu.vul_sources bvs on bvs.vul_id = bv.vul_id
		left join bdu.vul_cwe bvc on bvc.vul_id = bv.vul_id
		left join bdu.cwe bc on bc.cwe_id = bvc.cwe_id
		where pkg_assm."version">=dpv."version" and ds.st_name <> 'open');
	end if;
	END;
$$;


ALTER FUNCTION maintenance.get_assm_cve(resolved boolean, asm_id integer) OWNER TO owner;

--
-- Name: get_joint_assm(integer); Type: PROCEDURE; Schema: maintenance; Owner: owner
--

CREATE PROCEDURE maintenance.get_joint_assm(IN a_id integer)
    LANGUAGE plpgsql
    AS $$
declare
date_created timestamptz;
proj_id integer;
	begin

		select prj_id into proj_id
		from repositories.assembly a
		where assm_id = a_id;
	

		select assm_date_created into date_created
		from repositories.assembly a
		where assm_id = a_id;

		insert into maintenance.assm_vul
		(pkg_vul_id, pkg_name,  joint_vers, cve_vers, cve_name, cve_desc,
         st_name, urg_name, rep_name, link,
         vul_ident, vul_name, vul_desc, date_discovered,
         cvss2_vector, cvss2_score, cvss3_vector, cvss3_score,
         severity, cwe_name, url)
		select dense_rank() over (order by join_assm.pkg_name) as s, 
 join_assm.pkg_name, join_assm.vers,  pv."version",
		dc.cve_name, dc.cve_desc, ds.st_name, du.urg_name,dr.rep_name, bi.link, bv.vul_ident, bv.vul_name, bv.vul_desc, bv.date_discovered, bv.cvss2_vector,
		bv.cvss2_score, bv.cvss3_vector, bv.cvss3_score, bv.severity, bc.cwe_name, bvs.url
		from
		(
			select p.pkg_name, max(pv."version") as vers, max(a.assm_date_created) as max_date
			from repositories.pkg_version pv, repositories.pkg_version pv2
			join repositories.assm_pkg_vrs apv on apv.pkg_vrs_id = pv2.pkg_vrs_id
			join repositories.assembly a on a.assm_id = apv.assm_id
			join repositories.package p on p.pkg_id = pv2.pkg_id
			where assm_date_created <= date_created and prj_id = proj_id and pv.pkg_id=pv2.pkg_id
			group by p.pkg_name
		) as join_assm
		left join debtracker.package dp on join_assm.pkg_name = dp.pkg_name
		left join debtracker.pkg_version pv on dp.pkg_id =  pv.pkg_id and pv."version" < join_assm.vers
		left join debtracker.cve_rep dcr on dcr.fixed_pkg_vrs_id = pv.pkg_vrs_id or dcr.pkg_resolved_id = pv.pkg_vrs_id
		left join debtracker.repository dr on dr.rep_id = dcr.rep_id
		left join debtracker.urgency du on du.urg_id = dcr.urg_id
		left join debtracker.status ds on ds.st_id = dcr.st_id
		left join debtracker.cve dc on dc.cve_id = dcr.cve_id
		left join bdu.identifier bi on bi.ident_name = dc.cve_name
		left join bdu.vul_ident bvi on bvi.ident_id = bi.ident_id
		left join bdu.vulnerability bv on bv.vul_id = bvi.vul_id
		left join bdu.vul_sources bvs on bvs.vul_id = bv.vul_id
		left join bdu.vul_cwe bvc on bvc.vul_id = bv.vul_id
		left join bdu.cwe bc on bc.cwe_id = bvc.cwe_id;
		--where pv."version" < join_assm.vers;

	END;
$$;


ALTER PROCEDURE maintenance.get_joint_assm(IN a_id integer) OWNER TO owner;

--
-- Name: get_pkg_cve(boolean, integer); Type: FUNCTION; Schema: maintenance; Owner: owner
--

CREATE FUNCTION maintenance.get_pkg_cve(resolved boolean, p_id integer) RETURNS TABLE(pkg_name text, asm_version text, pkg_version text, cve_name text, cve_desc text, st_name text, urg_name text, rep_name text, link text, vul_ident text, vul_name text, vul_desc text, date_discovered timestamp with time zone, cvss2_vector text, cvss2_score text, cvss3_vector text, cvss3_score text, severity text, cwe_name text, url text)
    LANGUAGE plpgsql ROWS 10000
    AS $$
	begin
		if resolved = false then
		return query (select rp.pkg_name, rpv."version", dpv."version", dc.cve_name, dc.cve_desc,
         ds.st_name, du.urg_name, dr.rep_name, bi.link, bv.vul_ident, bv.vul_name, bv.vul_desc, bv.date_discovered, bv.cvss2_vector,
		bv.cvss2_score, bv.cvss3_vector, bv.cvss3_score, bv.severity, bc.cwe_name, bvs.url
        from repositories.pkg_version rpv
        join repositories.package rp on rpv.pkg_id = rp.pkg_id
        join debtracker.package dp using(pkg_name)
		join debtracker.pkg_version dpv on dp.pkg_id=dpv.pkg_id
		join debtracker.cve_rep dcr on dpv.pkg_vrs_id = dcr.fixed_pkg_vrs_id
		join debtracker.cve dc on dc.cve_id = dcr.cve_id
		join debtracker.repository dr on dr.rep_id=dcr.rep_id
		join debtracker.urgency du on du.urg_id=dcr.urg_id
		join debtracker.status ds on ds.st_id=dcr.st_id
		left join bdu.identifier bi on bi.ident_name = dc.cve_name
		left join bdu.vul_ident bvi on bvi.ident_id = bi.ident_id
		left join bdu.vulnerability bv on bv.vul_id = bvi.vul_id
		left join bdu.vul_sources bvs on bvs.vul_id = bv.vul_id
		left join bdu.vul_cwe bvc on bvc.vul_id = bv.vul_id
		left join bdu.cwe bc on bc.cwe_id = bvc.cwe_id
		where rpv.pkg_vrs_id = p_id and rpv."version">=dpv."version");
		end if;
		if resolved = true then
		return query (select rp.pkg_name, rpv."version", dpv."version", dc.cve_name, dc.cve_desc,
         ds.st_name, du.urg_name, dr.rep_name, bi.link, bv.vul_ident, bv.vul_name, bv.vul_desc, bv.date_discovered, bv.cvss2_vector,
		bv.cvss2_score, bv.cvss3_vector, bv.cvss3_score, bv.severity, bc.cwe_name, bvs.url
        from repositories.pkg_version rpv
        join repositories.package rp on rpv.pkg_id = rp.pkg_id
        join debtracker.package dp using(pkg_name)
		join debtracker.pkg_version dpv on dp.pkg_id=dpv.pkg_id
		join debtracker.cve_rep dcr on dpv.pkg_vrs_id = dcr.pkg_resolved_id
		join debtracker.cve dc on dc.cve_id = dcr.cve_id
		join debtracker.repository dr on dr.rep_id=dcr.rep_id
		join debtracker.urgency du on du.urg_id=dcr.urg_id
		join debtracker.status ds on ds.st_id=dcr.st_id
		left join bdu.identifier bi on bi.ident_name = dc.cve_name
		left join bdu.vul_ident bvi on bvi.ident_id = bi.ident_id
		left join bdu.vulnerability bv on bv.vul_id = bvi.vul_id
		left join bdu.vul_sources bvs on bvs.vul_id = bv.vul_id
		left join bdu.vul_cwe bvc on bvc.vul_id = bv.vul_id
		left join bdu.cwe bc on bc.cwe_id = bvc.cwe_id
		where rpv.pkg_vrs_id = p_id and rpv."version">=dpv."version" and ds.st_name<>'open');
	end if;
	END;
$$;


ALTER FUNCTION maintenance.get_pkg_cve(resolved boolean, p_id integer) OWNER TO owner;

--
-- Name: update_bdu(); Type: PROCEDURE; Schema: maintenance; Owner: owner
--

CREATE PROCEDURE maintenance.update_bdu()
    LANGUAGE plpgsql
    AS $$
declare
v_id INTEGER;
max_id INTEGER;
c_id INTEGER;
i_id integer;
vul RECORD;
cwe_name RECORD;
ident RECORD;
  begin
	  	select max(tc.cwe_id) into max_id from temp_bdu.cwe tc;
		SELECT setval('temp_bdu.cwe_cwe_id_seq', max_id, true) into max_id;

	 	select max(ti.ident_id) into max_id from temp_bdu.identifier ti;
		SELECT setval('temp_bdu.identifier_ident_id_seq', max_id, true) into max_id;

	 select max(tv.vul_id) into max_id from temp_bdu.vulnerability tv;
	SELECT setval('temp_bdu.vulnerability_vul_id_seq', max_id, true) into max_id;

	 select max(tvs.vul_src_id) into max_id from temp_bdu.vul_sources tvs;
	SELECT setval('temp_bdu.vul_sources_vul_src_id_seq', max_id, true) into max_id;

	  	insert into temp_bdu.cwe (cwe_name)
   		select c.cwe_name
   		from bdu.cwe c
   		where c.cwe_name not in(
   				select tc.cwe_name 
   				from temp_bdu.cwe tc);

   		insert into temp_bdu.identifier
   		(ident_type, link, ident_name)
    	select i.ident_type, i.link, i.ident_name
    	from bdu.identifier i
    	where i.ident_name not in(
    			select ti.ident_name 
    			from temp_bdu.identifier ti);

	  for vul in (select *
	  				from bdu.vulnerability
	  				where vul_ident not in (
	  				select vul_ident
	  				from temp_bdu.vul_ident))
	  	loop
			if vul.vul_ident not in (
			select vul_ident
	  		from temp_bdu.vul_ident) then
	  		
				insert into temp_bdu.vulnerability
	  			(vul_ident, vul_name, vul_desc,
    			date_discovered, severity, cvss2_vector,
    			cvss2_score, cvss3_vector, cvss3_score)
    			values (vul.vul_ident, vul.vul_name, vul.vul_desc,
    			vul.date_discovered, vul.severity, vul.cvss2_vector,
    			vul.cvss2_score, vul.cvss3_vector, vul.cvss3_score)
    			returning vul_id INTO v_id;
    		
	  		end if;
	  	
			insert into temp_bdu.vul_sources (url, vul_id)
    		select bvs.url, v_id
   			from bdu.vul_sources bvs
   			join vul v on v.vul_id = bvs.vul_id
			on conflict (vul_id) do nothing;
	
  			for cwe_name in (select cwe_name
  							from bdu.cwe
  							where cwe_id in (
  							select cwe_id 
  							from bdu.vul_cwe vc
  							where vul_id  = vul.vul_id))
  			loop
	  				select cwe_id into c_id 
	  				from temp_bdu.cwe 
	  				where cwe_name = cwe_name; 
	  				
  					insert into temp_bdu.vul_cwe
  					(vul_id, cwe_id)
  					values
  					(v_id, c_id)
  					on conflict(vul_id, cwe_id) do nothing;
  			end loop;

  			for ident in (select ident_name
  							 from bdu.identifier 
  							 where ident_id in (
  							 select ident_id 
  							 from bdu.vul_ident 
  							 where vul_id = vul.vul_id))
  			loop	
	  				select ident_id into i_id
	  				from temp_bdu.identifier
	  				where ident_name = ident.ident_name;
	  				
  					insert into temp_bdu.vul_ident
  					(vul_id, ident_id)
  					values
  					(v_id, i_id)
  					on conflict (vul_id, ident_id) do nothing;
  			end loop;

  		end loop;

  END;
 $$;


ALTER PROCEDURE maintenance.update_bdu() OWNER TO owner;

--
-- Name: update_debtracker(); Type: PROCEDURE; Schema: maintenance; Owner: owner
--

CREATE PROCEDURE maintenance.update_debtracker()
    LANGUAGE plpgsql
    AS $$
declare 
max_id INTEGER;
  begin

	 select max(st_id) into max_id from temp_debtracker.status;
	SELECT setval('temp_debtracker.status_st_id_seq', max_id, true) into max_id;

	 select max(urg_id) into max_id from temp_debtracker.urgency;
	SELECT setval('temp_debtracker.urgency_urg_id_seq', max_id, true) into max_id;

	 select max(cve_id) into max_id from temp_debtracker.cve;
	SELECT setval('temp_debtracker.cve_cve_id_seq', max_id, true) into max_id;

	 select max(pkg_id) into max_id from temp_debtracker.package;
	SELECT setval('temp_debtracker.package_pkg_id_seq', max_id, true) into max_id;

	 select max(rel_id) into max_id from temp_debtracker."release";
	SELECT setval('temp_debtracker.release_rel_id_seq', max_id, true) into max_id;

	 select max(rep_id) into max_id from temp_debtracker.repository;
	SELECT setval('temp_debtracker.repository_rep_id_seq', max_id, true) into max_id;

	 select max(pkg_vrs_id) into max_id from temp_debtracker.pkg_version;
	SELECT setval('temp_debtracker.pkg_version_pkg_vrs_id_seq', max_id, true) into max_id;

	insert into temp_debtracker.status
	(st_name)
	select st_name
	from debtracker.status
	on conflict (st_name) do nothing;

	insert into temp_debtracker.urgency
	(urg_name)
	select urg_name
	from debtracker.urgency
	on conflict (urg_name) do nothing;

	insert into temp_debtracker.cve
	(cve_name, cve_desc)
	select cve_name, cve_desc
	from debtracker.cve
	on conflict (cve_name) do nothing;

	insert into temp_debtracker."release"
	(rel_name)
	select rel_name
	from debtracker."release"
	on conflict (rel_name) do nothing;

	insert into temp_debtracker.repository
	(rep_name, rel_id)
	select dr.rep_name, tr.rel_id
	from debtracker.repository dr
   	join debtracker."release" drr on drr.rel_id = dr.rel_id
   	join temp_debtracker."release" tr using(rel_name)
   	on conflict (rep_name) do nothing;
	
 	insert into temp_debtracker.package
 	(pkg_name)
 	select pkg_name
 	from debtracker.package
 	on conflict (pkg_name) do nothing;
 
 	insert into temp_debtracker.pkg_version
 	("version", pkg_id)
	SELECT "version", pkg_id FROM (
  	SELECT dpv."version", tp.pkg_id 
  	FROM debtracker.pkg_version dpv
  	join debtracker.package dp on dp.pkg_id = dpv.pkg_id  
  	join temp_debtracker.package tp using(pkg_name)
	) as pkg
	WHERE ("version", pkg_id) not in (select "version", pkg_id 
					from temp_debtracker.pkg_version);
								
		insert into temp_debtracker.cve_rep
    (cve_id, rep_id, pkg_resolved_id, urg_id, st_id, fixed_pkg_vrs_id)
	select
  	tdc.cve_id,
  	tdr.rep_id,
  	(select pkg_vrs_id from temp_debtracker.pkg_version tdpv where tdpv.pkg_id = tdp.pkg_id and tdpv."version" = dpv."version") as resolved,
  	(select urg_id from temp_debtracker.urgency tdu where tdu.urg_name = du.urg_name) as urg_id,
  	(select st_id from temp_debtracker.status tds where tds.st_name = ds.st_name) as st_id,
  	(select pkg_vrs_id from temp_debtracker.pkg_version tdpvv where tdpvv.pkg_id = tdp.pkg_id and tdpvv."version" = dpvv."version") as fixed
	from debtracker.cve_rep dcr
	join debtracker.cve dc on dcr.cve_id = dc.cve_id
	join debtracker.repository dr on dcr.rep_id = dr.rep_id
	join debtracker.urgency du on dcr.urg_id = du.urg_id
	join debtracker.status ds on dcr.st_id = ds.st_id
	join debtracker.pkg_version dpv on dcr.pkg_resolved_id = dpv.pkg_vrs_id
	join debtracker.package  dp on dp.pkg_id = dpv.pkg_id
	join debtracker.pkg_version dpvv on dcr.fixed_pkg_vrs_id = dpvv.pkg_vrs_id
	join temp_debtracker.cve tdc on tdc.cve_name = dc.cve_name
	join temp_debtracker.repository tdr on tdr.rep_name = dr.rep_name
	join temp_debtracker.package tdp on tdp.pkg_name = dp.pkg_name 
	left join temp_debtracker.cve_rep tdcr on tdcr.rep_id = tdr.rep_id and tdcr.cve_id = tdc.cve_id
	where tdcr.rep_id is null;
 end;
$$;


ALTER PROCEDURE maintenance.update_debtracker() OWNER TO owner;

--
-- Name: update_rep_pkg(); Type: PROCEDURE; Schema: maintenance; Owner: owner
--

CREATE PROCEDURE maintenance.update_rep_pkg()
    LANGUAGE plpgsql
    AS $$
	declare
max_id INTEGER;
	begin
	select max(arch_id) into max_id from repositories.architecture;
	SELECT setval('repositories.architecture_arch_id_seq', max_id, true) into max_id;

		select max(assm_id) into max_id from repositories.assembly;
	SELECT setval('repositories.assembly_assm_id_seq', max_id, true) into max_id;

select max(id) into max_id from repositories.changelog;
	SELECT setval('repositories.changelog_id_seq', max_id, true) into max_id;

		select max(rel_id) into max_id from repositories."release";
	SELECT setval('repositories.release_rel_id_seq', max_id, true) into max_id;

select max(prj_id) into max_id from repositories.project;
	SELECT setval('repositories.project_prj_id_seq', max_id, true) into max_id;

		select max(urg_id) into max_id from repositories.urgency;
	SELECT setval('repositories.urgency_urg_id_seq', max_id, true) into max_id;

	select max(pkg_vrs_id) into max_id from repositories.pkg_version;
	SELECT setval('repositories.pkg_version_pkg_vrs_id_seq', max_id, true) into max_id;

		select max(pkg_id) into max_id from repositories.package;
	SELECT setval('repositories.package_pkg_id_seq', max_id, true) into max_id;

	END;
$$;


ALTER PROCEDURE maintenance.update_rep_pkg() OWNER TO owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cwe; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.cwe (
    cwe_id integer NOT NULL,
    cwe_name text NOT NULL
);


ALTER TABLE bdu.cwe OWNER TO owner;

--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.cwe_cwe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.cwe_cwe_id_seq OWNER TO owner;

--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.cwe_cwe_id_seq OWNED BY bdu.cwe.cwe_id;


--
-- Name: identifier; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.identifier (
    ident_id integer NOT NULL,
    ident_type text,
    link text,
    ident_name text
);


ALTER TABLE bdu.identifier OWNER TO owner;

--
-- Name: identifier_ident_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.identifier_ident_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.identifier_ident_id_seq OWNER TO owner;

--
-- Name: identifier_ident_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.identifier_ident_id_seq OWNED BY bdu.identifier.ident_id;


--
-- Name: vul_cwe; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_cwe (
    vul_id integer NOT NULL,
    cwe_id integer NOT NULL
);


ALTER TABLE bdu.vul_cwe OWNER TO owner;

--
-- Name: vul_ident; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_ident (
    vul_id integer NOT NULL,
    ident_id integer NOT NULL
);


ALTER TABLE bdu.vul_ident OWNER TO owner;

--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vul_ident_vul_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vul_ident_vul_id_seq OWNER TO owner;

--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vul_ident_vul_id_seq OWNED BY bdu.vul_ident.vul_id;


--
-- Name: vul_sources; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_sources (
    vul_src_id integer NOT NULL,
    url text,
    vul_id integer
);


ALTER TABLE bdu.vul_sources OWNER TO owner;

--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vul_sources_vul_src_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vul_sources_vul_src_id_seq OWNER TO owner;

--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vul_sources_vul_src_id_seq OWNED BY bdu.vul_sources.vul_src_id;


--
-- Name: vulnerability; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vulnerability (
    vul_id integer NOT NULL,
    vul_ident text,
    vul_name text,
    vul_desc text,
    date_discovered timestamp with time zone,
    severity text,
    cvss2_vector text,
    cvss2_score text,
    cvss3_vector text,
    cvss3_score text
);


ALTER TABLE bdu.vulnerability OWNER TO owner;

--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vulnerability_vul_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vulnerability_vul_id_seq OWNER TO owner;

--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vulnerability_vul_id_seq OWNED BY bdu.vulnerability.vul_id;


--
-- Name: cve; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.cve (
    cve_id integer NOT NULL,
    cve_name text NOT NULL,
    cve_desc text
);


ALTER TABLE debtracker.cve OWNER TO owner;

--
-- Name: cve_cve_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.cve_cve_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.cve_cve_id_seq OWNER TO owner;

--
-- Name: cve_cve_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.cve_cve_id_seq OWNED BY debtracker.cve.cve_id;


--
-- Name: cve_rep; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.cve_rep (
    cve_id integer NOT NULL,
    rep_id integer NOT NULL,
    pkg_resolved_id integer,
    urg_id integer,
    st_id integer,
    fixed_pkg_vrs_id integer
);


ALTER TABLE debtracker.cve_rep OWNER TO owner;

--
-- Name: package; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.package (
    pkg_id integer NOT NULL,
    pkg_name text
);


ALTER TABLE debtracker.package OWNER TO owner;

--
-- Name: package_pkg_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.package_pkg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.package_pkg_id_seq OWNER TO owner;

--
-- Name: package_pkg_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.package_pkg_id_seq OWNED BY debtracker.package.pkg_id;


--
-- Name: pkg_version; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.pkg_version (
    pkg_vrs_id integer NOT NULL,
    version text,
    pkg_id integer
);


ALTER TABLE debtracker.pkg_version OWNER TO owner;

--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.pkg_version_pkg_vrs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.pkg_version_pkg_vrs_id_seq OWNER TO owner;

--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.pkg_version_pkg_vrs_id_seq OWNED BY debtracker.pkg_version.pkg_vrs_id;


--
-- Name: release; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.release (
    rel_id integer NOT NULL,
    rel_name text NOT NULL
);


ALTER TABLE debtracker.release OWNER TO owner;

--
-- Name: release_rel_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.release_rel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.release_rel_id_seq OWNER TO owner;

--
-- Name: release_rel_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.release_rel_id_seq OWNED BY debtracker.release.rel_id;


--
-- Name: repository; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.repository (
    rep_id integer NOT NULL,
    rep_name text NOT NULL,
    rel_id integer
);


ALTER TABLE debtracker.repository OWNER TO owner;

--
-- Name: repository_rep_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.repository_rep_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.repository_rep_id_seq OWNER TO owner;

--
-- Name: repository_rep_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.repository_rep_id_seq OWNED BY debtracker.repository.rep_id;


--
-- Name: status; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.status (
    st_id integer NOT NULL,
    st_name text
);


ALTER TABLE debtracker.status OWNER TO owner;

--
-- Name: status_st_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.status_st_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.status_st_id_seq OWNER TO owner;

--
-- Name: status_st_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.status_st_id_seq OWNED BY debtracker.status.st_id;


--
-- Name: urgency; Type: TABLE; Schema: debtracker; Owner: owner
--

CREATE TABLE debtracker.urgency (
    urg_id integer NOT NULL,
    urg_name text
);


ALTER TABLE debtracker.urgency OWNER TO owner;

--
-- Name: urgency_urg_id_seq; Type: SEQUENCE; Schema: debtracker; Owner: owner
--

CREATE SEQUENCE debtracker.urgency_urg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE debtracker.urgency_urg_id_seq OWNER TO owner;

--
-- Name: urgency_urg_id_seq; Type: SEQUENCE OWNED BY; Schema: debtracker; Owner: owner
--

ALTER SEQUENCE debtracker.urgency_urg_id_seq OWNED BY debtracker.urgency.urg_id;


--
-- Name: schema_vrs; Type: TABLE; Schema: maintenance; Owner: owner
--

CREATE TABLE maintenance.schema_vrs (
    schm_name text NOT NULL,
    schm_vrs text NOT NULL,
    schm_user text NOT NULL,
    schm_url text,
    date_changed timestamp with time zone NOT NULL
);


ALTER TABLE maintenance.schema_vrs OWNER TO owner;

--
-- Name: update_info; Type: TABLE; Schema: maintenance; Owner: owner
--

CREATE TABLE maintenance.update_info (
    ui_date timestamp with time zone DEFAULT now() NOT NULL,
    ui_user text DEFAULT CURRENT_USER,
    ui_records integer,
    ui_name text
);


ALTER TABLE maintenance.update_info OWNER TO owner;

--
-- Name: architecture; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.architecture (
    arch_id integer NOT NULL,
    arch_name text NOT NULL
);


ALTER TABLE repositories.architecture OWNER TO owner;

--
-- Name: architecture_arch_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.architecture_arch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.architecture_arch_id_seq OWNER TO owner;

--
-- Name: architecture_arch_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.architecture_arch_id_seq OWNED BY repositories.architecture.arch_id;


--
-- Name: assembly; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.assembly (
    assm_id integer NOT NULL,
    assm_date_created timestamp with time zone,
    assm_desc text,
    prj_id integer NOT NULL,
    assm_version text NOT NULL
);


ALTER TABLE repositories.assembly OWNER TO owner;

--
-- Name: assembly_assm_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.assembly_assm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.assembly_assm_id_seq OWNER TO owner;

--
-- Name: assembly_assm_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.assembly_assm_id_seq OWNED BY repositories.assembly.assm_id;


--
-- Name: assm_pkg_vrs; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.assm_pkg_vrs (
    pkg_vrs_id integer NOT NULL,
    assm_id integer NOT NULL
);


ALTER TABLE repositories.assm_pkg_vrs OWNER TO owner;

--
-- Name: changelog; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.changelog (
    id integer NOT NULL,
    log_desc text NOT NULL,
    urg_id integer NOT NULL,
    pkg_vrs_id integer,
    date_added timestamp with time zone NOT NULL,
    log_ident text,
    rep_name text
);


ALTER TABLE repositories.changelog OWNER TO owner;

--
-- Name: changelog_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.changelog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.changelog_id_seq OWNER TO owner;

--
-- Name: changelog_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.changelog_id_seq OWNED BY repositories.changelog.id;


--
-- Name: package; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.package (
    pkg_id integer NOT NULL,
    pkg_name text NOT NULL
);


ALTER TABLE repositories.package OWNER TO owner;

--
-- Name: package_pkg_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.package_pkg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.package_pkg_id_seq OWNER TO owner;

--
-- Name: package_pkg_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.package_pkg_id_seq OWNED BY repositories.package.pkg_id;


--
-- Name: pkg_version; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.pkg_version (
    pkg_vrs_id integer NOT NULL,
    pkg_date_created timestamp with time zone,
    author_name text,
    pkg_id integer,
    version text
);


ALTER TABLE repositories.pkg_version OWNER TO owner;

--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.pkg_version_pkg_vrs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.pkg_version_pkg_vrs_id_seq OWNER TO owner;

--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.pkg_version_pkg_vrs_id_seq OWNED BY repositories.pkg_version.pkg_vrs_id;


--
-- Name: project; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.project (
    prj_id integer NOT NULL,
    prj_name text NOT NULL,
    rel_id integer,
    prj_desc text,
    vendor text,
    arch_id integer
);


ALTER TABLE repositories.project OWNER TO owner;

--
-- Name: project_prj_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.project_prj_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.project_prj_id_seq OWNER TO owner;

--
-- Name: project_prj_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.project_prj_id_seq OWNED BY repositories.project.prj_id;


--
-- Name: release; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.release (
    rel_id integer NOT NULL,
    rel_name text NOT NULL
);


ALTER TABLE repositories.release OWNER TO owner;

--
-- Name: release_rel_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.release_rel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.release_rel_id_seq OWNER TO owner;

--
-- Name: release_rel_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.release_rel_id_seq OWNED BY repositories.release.rel_id;


--
-- Name: urgency; Type: TABLE; Schema: repositories; Owner: owner
--

CREATE TABLE repositories.urgency (
    urg_id integer NOT NULL,
    urg_name text NOT NULL
);


ALTER TABLE repositories.urgency OWNER TO owner;

--
-- Name: urgency_urg_id_seq; Type: SEQUENCE; Schema: repositories; Owner: owner
--

CREATE SEQUENCE repositories.urgency_urg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE repositories.urgency_urg_id_seq OWNER TO owner;

--
-- Name: urgency_urg_id_seq; Type: SEQUENCE OWNED BY; Schema: repositories; Owner: owner
--

ALTER SEQUENCE repositories.urgency_urg_id_seq OWNED BY repositories.urgency.urg_id;


--
-- Name: cwe cwe_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe ALTER COLUMN cwe_id SET DEFAULT nextval('bdu.cwe_cwe_id_seq'::regclass);


--
-- Name: identifier ident_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier ALTER COLUMN ident_id SET DEFAULT nextval('bdu.identifier_ident_id_seq'::regclass);


--
-- Name: vul_ident vul_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident ALTER COLUMN vul_id SET DEFAULT nextval('bdu.vul_ident_vul_id_seq'::regclass);


--
-- Name: vul_sources vul_src_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources ALTER COLUMN vul_src_id SET DEFAULT nextval('bdu.vul_sources_vul_src_id_seq'::regclass);


--
-- Name: vulnerability vul_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability ALTER COLUMN vul_id SET DEFAULT nextval('bdu.vulnerability_vul_id_seq'::regclass);


--
-- Name: cve cve_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve ALTER COLUMN cve_id SET DEFAULT nextval('debtracker.cve_cve_id_seq'::regclass);


--
-- Name: package pkg_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.package ALTER COLUMN pkg_id SET DEFAULT nextval('debtracker.package_pkg_id_seq'::regclass);


--
-- Name: pkg_version pkg_vrs_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.pkg_version ALTER COLUMN pkg_vrs_id SET DEFAULT nextval('debtracker.pkg_version_pkg_vrs_id_seq'::regclass);


--
-- Name: release rel_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.release ALTER COLUMN rel_id SET DEFAULT nextval('debtracker.release_rel_id_seq'::regclass);


--
-- Name: repository rep_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.repository ALTER COLUMN rep_id SET DEFAULT nextval('debtracker.repository_rep_id_seq'::regclass);


--
-- Name: status st_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.status ALTER COLUMN st_id SET DEFAULT nextval('debtracker.status_st_id_seq'::regclass);


--
-- Name: urgency urg_id; Type: DEFAULT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.urgency ALTER COLUMN urg_id SET DEFAULT nextval('debtracker.urgency_urg_id_seq'::regclass);


--
-- Name: architecture arch_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.architecture ALTER COLUMN arch_id SET DEFAULT nextval('repositories.architecture_arch_id_seq'::regclass);


--
-- Name: assembly assm_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assembly ALTER COLUMN assm_id SET DEFAULT nextval('repositories.assembly_assm_id_seq'::regclass);


--
-- Name: changelog id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.changelog ALTER COLUMN id SET DEFAULT nextval('repositories.changelog_id_seq'::regclass);


--
-- Name: package pkg_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.package ALTER COLUMN pkg_id SET DEFAULT nextval('repositories.package_pkg_id_seq'::regclass);


--
-- Name: pkg_version pkg_vrs_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.pkg_version ALTER COLUMN pkg_vrs_id SET DEFAULT nextval('repositories.pkg_version_pkg_vrs_id_seq'::regclass);


--
-- Name: project prj_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.project ALTER COLUMN prj_id SET DEFAULT nextval('repositories.project_prj_id_seq'::regclass);


--
-- Name: release rel_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.release ALTER COLUMN rel_id SET DEFAULT nextval('repositories.release_rel_id_seq'::regclass);


--
-- Name: urgency urg_id; Type: DEFAULT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.urgency ALTER COLUMN urg_id SET DEFAULT nextval('repositories.urgency_urg_id_seq'::regclass);


--
-- Data for Name: cwe; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.cwe (cwe_id, cwe_name) FROM stdin;
\.


--
-- Data for Name: identifier; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.identifier (ident_id, ident_type, link, ident_name) FROM stdin;
\.


--
-- Data for Name: vul_cwe; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_cwe (vul_id, cwe_id) FROM stdin;
\.


--
-- Data for Name: vul_ident; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_ident (vul_id, ident_id) FROM stdin;
\.


--
-- Data for Name: vul_sources; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_sources (vul_src_id, url, vul_id) FROM stdin;
\.


--
-- Data for Name: vulnerability; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vulnerability (vul_id, vul_ident, vul_name, vul_desc, date_discovered, severity, cvss2_vector, cvss2_score, cvss3_vector, cvss3_score) FROM stdin;
\.


--
-- Data for Name: cve; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.cve (cve_id, cve_name, cve_desc) FROM stdin;
\.


--
-- Data for Name: cve_rep; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.cve_rep (cve_id, rep_id, pkg_resolved_id, urg_id, st_id, fixed_pkg_vrs_id) FROM stdin;
\.


--
-- Data for Name: package; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.package (pkg_id, pkg_name) FROM stdin;
\.


--
-- Data for Name: pkg_version; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.pkg_version (pkg_vrs_id, version, pkg_id) FROM stdin;
\.


--
-- Data for Name: release; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.release (rel_id, rel_name) FROM stdin;
\.


--
-- Data for Name: repository; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.repository (rep_id, rep_name, rel_id) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.status (st_id, st_name) FROM stdin;
\.


--
-- Data for Name: urgency; Type: TABLE DATA; Schema: debtracker; Owner: owner
--

COPY debtracker.urgency (urg_id, urg_name) FROM stdin;
\.


--
-- Data for Name: schema_vrs; Type: TABLE DATA; Schema: maintenance; Owner: owner
--

COPY maintenance.schema_vrs (schm_name, schm_vrs, schm_user, schm_url, date_changed) FROM stdin;
\.


--
-- Data for Name: update_info; Type: TABLE DATA; Schema: maintenance; Owner: owner
--

COPY maintenance.update_info (ui_date, ui_user, ui_records, ui_name) FROM stdin;
\.


--
-- Data for Name: architecture; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.architecture (arch_id, arch_name) FROM stdin;
\.


--
-- Data for Name: assembly; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.assembly (assm_id, assm_date_created, assm_desc, prj_id, assm_version) FROM stdin;
1	2024-07-15 11:06:29.498131+03	/home/ivandor/u/onyx-2.1	1	2.1
\.


--
-- Data for Name: assm_pkg_vrs; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.assm_pkg_vrs (pkg_vrs_id, assm_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
\.


--
-- Data for Name: changelog; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.changelog (id, log_desc, urg_id, pkg_vrs_id, date_added, log_ident, rep_name) FROM stdin;
1	  * Non-maintainer upload.\n  * Rebuild for stretch.\n	1	3	2021-05-10 18:17:51+03		unstable
2	  * New upstream release\n	1	23	2020-10-20 00:00:12+03		unstable
3	  * Upload to unstable\n  * debian/libraw20.symbols: drop duplicates and\n   restrict to 64 bits\n	1	24	2020-08-18 16:45:30+03		unstable
4	  * debian/libraw20.symbols: drop MISSING and update others\n	1	25	2020-08-05 00:43:02+03		experimental
5	  * debian/libraw20.symbols: file updated\n	1	26	2020-08-04 22:11:25+03		experimental
6	 [ Matteo F. Vescovi ]\n  * New upstream release\n    This release fixes CVE-2020-15503:\n    | LibRaw before 0.20-RC1 lacks a thumbnail size range check.\n   | This affects decoders/unpack_thumb.cpp,\n   | postprocessing/mem_image.cpp, and utils/thumb_utils.cpp.\n   | For example,\n    | malloc(sizeof(libraw_processed_image_t)+T.tlength) occurs\n   | without validating T.tlength.\n  * debian/: SONAME bump 19 -> 20\n  * debian/control:\n    - debhelper bump 12 -> 13\n    - S-V bump 4.4.0 -> 4.5.0 (no changes needed)\n    - RRR set\n  * debian/tests/smoketest: path adapted\n  * debian/copyright: entries for unused files and licenses removed\n  * debian/rules: drop useless files installation\n  * debian/libraw20.symbols: missing and new symbols added\n [ Sebastien Bacher ]\n  * debian/tests/build: use the correct compiler for\n    autopkgtest cross-testing. (Closes: #954886)\n	1	27	2020-07-30 01:09:36+03	 CVE-2020-15503,	experimental
7	  * New upstream release\n	1	28	2019-08-29 00:45:51+03		unstable
8	  * New upstream release\n  * debian/: really bump debhelper to v12\n  * debian/control: S-V bump 4.3.0 -> 4.4.0 (no changes needed)\n	1	29	2019-08-09 23:29:04+03		unstable
9	  * New upstream release\n    - debian/patches/: patchset dropped (applied upstream)\n	1	30	2019-07-11 23:46:26+03		unstable
10	  * debian/patches/: patchset updated\n    - 0001-Fix_CVE-2018-20365_for_real.patch added\n  * debian/: debhelper bump 11 -> 12\n	1	31	2019-01-10 23:51:18+03	 CVE-2018,	unstable
11	  * New upstream release\n   This minor release fixes the following\n   security issues:\n    - CVE-2018-20337\n    - CVE-2018-20363\n    - CVE-2018-20364\n    - CVE-2018-20365\n  * debian/control: S-V bump 4.2.1 -> 4.3.0 (no changes needed)\n	1	32	2018-12-27 23:25:22+03	 CVE-2018-20337, CVE-2018-20363, CVE-2018-20364, CVE-2018-20365,	unstable
12	  * New upstream release\n	1	33	2018-12-16 16:34:20+03		unstable
13	 [ Jeremy Bicha ]\n  * debian/libraw19.symbols: Mark 2 symbols as optional\n    which disappear when built with -O3 on Ubuntu's ppc64el\n	1	34	2018-11-10 00:53:58+03		unstable
14	  * Upload to unstable\n  * debian/control: S-V bump 4.1.5 -> 4.2.1 (no changes needed)\n	1	35	2018-08-28 00:10:52+03		unstable
15	  * debian/libraw19.symbols: symbols updated to fix buildd FTBFS\n	1	36	2018-07-27 00:34:33+03		experimental
16	  * New upstream release\n    - debian/: SONAME bump 16 -> 19\n    - debian/libraw19.symbols: symbols updated\n	1	37	2018-07-18 23:49:27+03		experimental
17	  * New upstream release\n  * debian/control: S-V bump 4.1.4 -> 4.1.5 (no changes needed)\n	1	38	2018-07-13 01:05:29+03		unstable
18	  * New upstream release (Closes: #897185, #897186)\n    - Fix CVE-2018-10528 and CVE-2018-10529\n  * debian/control: S-V bump 4.1.3 -> 4.1.4 (no changes needed)\n	2	39	2018-05-30 00:40:01+03	 CVE-2018-10528, CVE-2018-10529,	unstable
19	 [ Mattia Rizzolo ]\n  * d/control: Update the Vcs-* fields for the move to salsa.debian.org.\n  * Use HTTPS in the Homepage field.\n  * d/rules: make use of dpkg-buildflags facilities to set LDFLAGS\n    built files are bit-by-bit reproducible.\n * d/rules: drop option already passed by dh_auto_configure --prefix=/usr\n  * d/rules: drop manual invocation of dh_makeshlibs.\n  * Simplify symbols file, collating the architectures filters\n    into arch-bits=64/32.\n [ Matteo F. Vescovi ]\n  * debian/libraw16.symbols: MISSING entries dropped\n	1	40	2018-03-07 00:33:44+03		unstable
20	  * New upstream release\n    - debian/libraw16.symbols: symbols updated\n	1	41	2018-03-04 17:29:17+03		unstable
21	 [ Jason Duerstock ]\n  * debian/libraw16.symbols: symbols refreshed to add ia64 architecture\n   (Closes: #888061)\n	1	42	2018-01-24 16:44:01+03		unstable
22	  * New upstream release\n  * debian/copyright: copyright-format moved to https://\n	1	43	2018-01-23 01:02:49+03		unstable
23	  * New upstream release\n  * debian/compat: 10 -> 11\n  * debian/control: debhelper versioning 10 -> 11\n  * debian/control: S-V bump 4.1.1 -> 4.1.3 (no changes needed)\n  * debian/libraw16.symbols: update MISSING symbols\n  * debian/libraw-doc.doc-base: fix installation path\n	1	44	2018-01-07 16:04:54+03		unstable
24	  * New upstream release (Closes: #874729)\n  * debian/: autotools-dev usage dropped\n  * debian/control: S-V bump 4.0.0 -> 4.1.1 (no changes needed)\n	1	45	2017-10-06 22:51:38+03		unstable
25	  * Upload to unstable\n  * debian/control: S-V bump 3.9.8 => 4.0.0 (no changes needed)\n	1	46	2017-06-22 18:32:33+03		unstable
26	  * New upstream release\n    - debian/libraw16.symbols: MISSING symbols updated\n	1	47	2017-03-25 15:45:42+03		experimental
27	  * New upstream release\n	1	48	2017-03-03 16:57:36+03		experimental
28	  * New upstream release\n    - debian/: SONAME bump libraw15 => libraw16\n    - debian/libraw16.symbols: symbols updated\n    - debian/copyright: licenses updated\n    - debian/patches/: patchset dropped (applied upstream)\n  * debian/: bump compatibility 9 -> 10\n	1	49	2017-01-02 15:52:44+03		experimental
29	  * debian/patches/: patchset updated (again)\n    - 0001-Fix_gcc6_narrowing_error.patch replaced with\n      0001-Fix_gcc6_narrowing_conversion.patch since it\n      was causing FTBFS on most little-endian architectures\n     Thanks to Alex Tutubalin (upstream) for the quick fix.\n	1	50	2016-08-25 23:29:57+03		unstable
30	  * debian/patches/: patchset updated\n    - 0001-Fix_dcraw_narrowing_for_gcc6.patch dropped\n     (wrong approach to fix the issue)\n    - 0001-Fix_gcc6_narrowing_error.patch added (Closes: #835350)\n	1	51	2016-08-24 23:26:35+03		unstable
31	  * debian/patches/: patchset updated (Closes: #811744)\n    - 0001-Fix_dcraw_narrowing_for_gcc6.patch refreshed\n     Thanks to Alex Tutubalin (upstream dev) for the advice.\n	1	52	2016-07-28 00:33:34+03		unstable
32	  * debian/patches/: patchset initiated (Closes: #811744)\n    - 0001-Fix_dcraw_narrowing_for_gcc6.patch added\n	1	53	2016-06-30 23:12:11+03		unstable
33	  * debian/control: libjasper-dev b-dep dropped (Closes: #818204)\n	1	54	2016-06-26 15:22:59+03		unstable
34	  * New upstream release\n  * debian/control: Maintainer field updated.\n   Sadly, the Shotwell Team has dissolved.\n   Now the LibRaw is under PhotoTools Maintainers umbrella.\n  * debian/control: S-V bump 3.9.6 -> 3.9.8 (no changes needed)\n  * debian/control: Vcs-* fields updated for https:// usage\n  * debian/libraw15.symbols: symbols updated\n	1	55	2016-05-25 23:02:07+03		unstable
35	  * New upstream release (Closes: #806809)\n    - Fix CVE-2015-8366 and CVE-2015-8367\n	2	56	2015-12-03 23:19:12+03	 CVE-2015-8366, CVE-2015-8367,	unstable
82	  * Adding patch from libungif to fix CVE-2005-2974 and CVE-2005-3350.\n  * Updating upstream homepage (Closes: #469561).\n	2	102	2008-03-07 16:40:00+03	 CVE-2005-2974, CVE-2005-3350,	unstable
36	  * New upstream release\n    - debian/: SONAME bump libraw10 => libraw15\n    - debian/rules: bump dh_makeshlibs to libraw15\n    - debian/libraw15.symbols: symbols refreshed\n  * debian/copyright: file updated\n	1	57	2015-10-16 11:03:52+03		unstable
37	  * New upstream release\n    - Fix CVE-2015-3885\n  * debian/control:\n    - XS-Testsuite field dropped\n    - Uploader e-mail address updated\n	2	58	2015-05-26 10:06:05+03	 CVE-2015-3885,	unstable
38	  * debian/control: strictly build-depends on libjpeg-dev.\n   Thanks to Ondřej Surý (ondrej) for the patch. (Closes: #763482)\n  * debian/control: S-V bump 3.9.5 => 3.9.6 (no changes needed)\n	1	59	2014-09-30 19:47:16+04		unstable
39	  * debian/watch: search path updated (Closes: #759650)\n	1	60	2014-08-29 12:29:55+04		unstable
40	  * debian/libraw10.symbols: updated for mips64/mips64el.\n   Thanks to YunQiang Su for the patch. (Closes: #758530)\n	1	61	2014-08-28 18:06:06+04		unstable
41	  * debian/control: new uploader (Closes: #755414)\n  * debian/control: VCS fields added\n  * debian/libraw10.symbols: mips64/mips64el archs added.\n   Thanks to YunQiang Su for the patch. (Closes: #754360)\n	1	62	2014-07-21 17:10:41+04		unstable
42	 [ Martin Pitt ]\n  * Fix autopkgtest: Add missing libraw-dev test dep, drop unnecessary\n    @builddeps@, and add missing "set -e" so that the test actually fails\n    properly. Also fix linking order to also work with binutils-gold.\n   These fixes closes: #750985.\n	1	63	2014-06-10 13:13:04+04		unstable
43	  * debian/libraw10.symbols:\n    - Update symbols to build against gcc-4.9 (Closes: #746875).\n  * debian/tests/testbuild:\n    - Provide a simple test to check whether the package is fucntional,\n     as per DEP8 (autopkgtests).\n	1	64	2014-06-07 20:43:23+04		unstable
44	 [ Adam Conrad ]\n  * debian/libraw10.symbols:\n    - Update symbols for arm64 and ppc64el (Closes: #745883).\n	1	65	2014-05-01 11:58:02+04		unstable
45	  * debian/libraw10.symbol:\n    - Handle 32-bit symbol differences (Closes: #740106).\n	1	66	2014-02-27 19:34:23+04		unstable
46	  * New upstream release.\n  * debian/control:\n    - Re-add myself as Uploader.\n    - Bump Standards-Version to 3.9.5.\n  * debian/copyright:\n    - Update license information.\n  * debian/libraw10.symbol:\n    - Renamed from libraw9.symbols.amd64 to match new binary, refreshed\n     with the new symbols (Closes: #738424).\n	1	67	2014-02-24 21:53:46+04		unstable
47	  * Team upload.\n  * New upstream release.\n    - Fix for CVE-2013-1438 (Closes: #721231).\n    - Fix for CVE-2013-1439 (Closes: #721338).\n    - Fix segmentaition fault when unprocessed_raw is passed -s option\n     wihout any parameter (Closes: #716423).\n  * debian/patches/4channels_parameter.patch:\n    - Dropped, applied upstream.\n  * debian/patches/typo.patch:\n    - Dropped, applied upstream.\n	3	68	2013-10-05 19:53:47+04	 CVE-2013-1438, CVE-2013-1439,	unstable
48	  * Team upload to unstable.\n  * New upstream release (Closes: #710353).\n    - Fix error handling for broken full-color images - CVE-2013-2126.\n    - Fix wrong data_maximum calcluation - CVE-2013-2127.\n  * debian/patches/4channels_parameter.patch:\n    - Fix segmentaition fault when 4channel is passed -s option without\n      any parameter (Closes: #715577).\n	3	69	2013-07-10 23:20:09+04	 CVE-2013-2126, CVE-2013-2127,	unstable
49	  * Team upload.\n  * New upstream release.\n  * debian/patches/typo.patch:\n    - Fix typo in help output.\n  * debian/control:\n    - Build-depend on dh-autoreconf.\n    - Build-depend on libjpeg8-dev | libjpeg-dev.\n    - Replace libraw5 with libraw9, SONAME changed.\n    - libraw-dev depends on libraw9 accordingly.\n  * debian/copyright:\n    - Update copyright years.\n  * debian/libraw9.install:\n    - Renamed from libraw5.install to match new binary.\n  * debian/libraw9.symbols.amd64:\n    - Renamed from libraw5.symbols.amd64 to match new binary.\n  * debian/rules:\n    - Build with autoreconf support.\n    - Build with DNG support (Closes: #699356).\n   - Pass "-Wl,-z,defs -Wl,--as-needed" to LDFLAGS.\n    - Update dh_makeshlibs call to match new binary.\n	3	70	2013-05-25 04:50:14+04		experimental
50	  * Team upload.\n  * Upload to unstable.\n  * debian/control:\n    - Remove deprecated DM-Upload-Allowed field.\n    - Bump Standards-Version to 3.9.4.\n	3	71	2013-05-12 22:47:35+04		unstable
51	  * Team upload.\n  * New upstream release (Closes: #682982).\n  * debian/control:\n    - Add DM-Upload-Allowed field.\n  * debian/watch:\n    - Use new redirector librawredir.debian.net.\n	3	72	2012-08-25 15:35:59+04		experimental
52	  * Team upload.\n  * debian/control:\n    - Add liblcms2-dev to libraw-dev Depends field.\n	3	73	2012-05-27 14:16:53+04		unstable
53	  * Team upload to unstable.\n  * New upstream release.\n  * Multi-arch support.\n  * debian/compat:\n    - Bump compatibility level to 9.\n  * debian/control:\n    - Bump Standards-Version to 3.9.3.\n  * debian/copyright:\n    - Update copyright years.\n    - Format now points to copyright-format site.\n  * debian/libraw5.symbols.amd64:\n    - Refresh symbols file.\n  * debian/rules:\n    - Bump minimum version in dh_makeshlibs to 0.14.6.\n	3	74	2012-05-06 19:59:10+04		unstable
54	  * Team upload.\n  * New upstream release.\n  * debian/control:\n    - Replace libraw2 with libraw5, SONAME changed.\n    - libraw-dev depends on libraw5 accordingly.\n    - Build-depend on pkg-config, libjasper-dev and liblcms2-dev.\n  * debian/libraw5.install:\n    - Renamed from libraw2.install to match new binary.\n  * debian/libraw5.symbols.amd64:\n    - Renamed from libraw2.symbols.amd64 to match new binary.\n  * debian/rules:\n    - Update dh_makeshlibs call to match new binary.\n	3	75	2011-09-24 17:32:39+04		experimental
55	  * Team upload.\n  * New upstream release.\n  * debian/control:\n    - Add Debian Shotwell Maintainers to Maintainers.\n    - Move Devid to Uploaders.\n    - Add autotools-dev to Build-Depends.\n    - Add libraw2 package, who provides the shared library.\n    - Add libraw2-bin package, who provides some tools to\n     manipulate RAW files.\n    - Bump Standards-Version to 3.9.2, no changes required.\n  * debian/copyright:\n    - Update copyright information.\n  * debian/rules:\n    - Build with autotools_dev to regenerate config.{sub,guess}.\n    - Manually set prefix to install shared library correctly.\n  * debian/watch:\n    - Upstream disabled listing support, watch file is no-op now.\n	3	76	2011-08-22 22:45:22+04		unstable
56	  * Set myself as maintainer (Closes: #613870).\n  * debian/control: add Timo Witte to Uploaders field.\n  * debian/install: install *.pc files in /usr/lib/pkgconfig (Closes: #613777).\n	3	77	2011-03-04 22:48:20+03		unstable
57	  * New upstream release (Closes: #607139).\n  * debian/control:\n    - Bump Standards-Version to 3.9.1, no changes required.\n  * debian/copyright:\n    - Update copyright years.\n	3	78	2011-02-09 00:53:51+03		unstable
59	  * Non-maintainer upload.\n  * Rebuild for stretch.\n	1	1	2021-05-14 10:53:03+03		unstable
83	  * Adding transitional packages to kick libungif out of the archive by force.\n  * Removing watch file (Closes: #453592).\n	2	103	2008-02-07 01:22:00+03		unstable
84	  * Adding legacy links for libungif4g/libungif4-dev.\n	3	104	2008-01-17 22:02:00+03		unstable
190	  * New upstream snapshot.\n	3	209	2010-06-15 22:25:26+04		experimental
191	  * New upstream snapshot.\n	3	210	2010-05-31 16:03:40+04		experimental
192	  * New upstream snapshot, switch back to waf.\n	3	211	2010-05-24 18:54:59+04		experimental
60	  * New Debian version.\n  * d/control:\n    - Update debhelper compatibility.\n    - Update standards version; no changes needed.\n  * d/patches:\n    - Add 'fix-spelling-errors-on-doc-pages'; Closes: #857609.\n    - Add 'fix-get-args-segment-violation';\n       Closes: #715963, #715964, #715967.\n    - Add 'recover-giffilter-docs'.\n    - Add 'add-gifsponge-docs'.\n  * d/rules:\n    - Install only html docs for installed binaries.\n    - Clean generated patched doc files.\n  * Update d/source/lintian-overrides tag.\n  * Remove d/giflib-tools.lintian-overrides: we have the manpages.\n	1	80	2020-12-21 00:07:35+03		unstable
61	 [ Ondřej Nový ]\n  * d/watch: Use https protocol.\n [ Andreas Metzler ]\n  * AUTHORS file not shipped anymore, update debian/*.docs.\n  * Uses straight make instead of autotools, adapt debian/rules accordingly.\n  * Use dh 12 compat level.\n  + Update debian/copyright, add Format specifier.\n [ David Suárez ]\n  * New upstream version:\n    - Add myself as maintainer; Closes: #834410.\n    - Fixes heap-based buffer overflow in DGifDecompressLine function.\n        CVE-2018-11490 sf#113; Closes: #904114\n    - Fixes MemorySanitizer: FPE on unknown address;\n        CVE-2019-15133 sf#119: Closes: #904113\n  * Acknowledges NMU's uploads.\n  * d/watch:\n    - Bump version.\n    - Don't run uupdate.\n    - Don't use debian redirector.\n  * d/patches:\n    - Drop '03-spelling_fixes.patch' and 'CVE-2016-3977.patch';\n       Applied upstream.\n    - Add 'install-only-distributed-binaries-manuals' patch.\n    - Add 'revert-GifQuantizeBuffer-remove-from-lib' patch.\n  * d/rules\n    - Don't force the rebuilding of manpages, the clean rule does the job.\n    - Remove the txt docs from giflib-tools; Not distributed.\n   - Remove 'dh_strip --dbgsym-migration'; Not needed anymore.\n    - Set DPKG_GENSYMBOLS_CHECK_LEVEL to 4.\n  * giflib-tools.manpages: point to the correct ones.\n  * d/control:\n    - Add 'Rules-Requires-Root' field.\n    - Update Standars version; no changes needed.\n    - Change VCS URL's.\n  * d/libgif7.symbols:\n    - Add 'Build-Depends-Package' field.\n    - Update symbols.\n  * d/copyright:\n    - Remove 'doc/gif87.txt'; Nows not distributed.\n    - Add myself on debian/* files.\n    - Add 'upstream-{Name,Contact}'.\n  * Wrap and sort.\n  * Add upstream metadata.\n  * Add lintian overrides for some giflib-tools manpages.\n  * Add lintian source override for sourceforge redirector.\n  * Drop libgif7.shlibs; not needed.\n	1	81	2019-12-08 23:18:23+03	 CVE-2018-11490, CVE-2019-15133, CVE-2016-3977,	unstable
62	  * QA upload.\n  * Heap-based buffer overflow in util/gif2rgb.c (CVE-2016-3977)\n   (Closes: #820526)\n	1	82	2018-06-05 21:58:51+03	 CVE-2016-3977,	unstable
63	  * QA upload.\n * New vcs repository generated from a) "gbp import-dscs --debsnap giflib",\n    b) old repo on alioth c) private repo for changes > 5.1.4-0.4.\n    Update Vcs* in debian/control, pointing to salsa.\n  * [lintian] Delete trailing whitespace in changelog.\n	3	83	2018-02-11 17:43:54+03		unstable
64	  * QA upload.\n  * Set maintainer to qa.\n  * Build with hardening=+bindnow.\n  * Switch to automatic dbgsym packages.\n  * 03-spelling_fixes.patch: Fix another two typoes found by lintian.\n  * Bump standards-version - No changes.\n * Use debhelper 10 compat, which uses autoreconf and --parallel by default.\n	3	84	2017-08-01 19:06:06+03		unstable
65	  * Non-maintainer upload.\n  * Remove patch/issue87 because that is already present in upstream.\n  * Remove patch/04-fprintf_format_error.patch which was commented out anyway.\n  * Install manpages supplied by upstream\n   Closes: #809439.\n	1	85	2016-10-18 01:16:00+03		unstable
66	  * Non-maintainer upload.\n  * CVE-2016-3977: gif2rgb: heap buffer overflow. Closes: #820526.\n	1	86	2016-06-10 01:24:07+03	 CVE-2016-3977,	unstable
67	  * Non-maintainer upload.\n  * Drop the local fix for issue #81, solved differently upstream.\n   Closes: #823481.\n	1	87	2016-05-08 18:40:28+03		unstable
68	  * Non-maintainer upload.\n  * New upstream version.\n  * Security issues already fixed in 5.1.2: CVE-2016-3977.\n   Closes: #820594, #820526.\n  * Update symbols file.\n	1	88	2016-04-25 21:19:43+03	 CVE-2016-3977,	unstable
69	  * Non-maintainer upload.\n [ Tobias Frost ]\n  * debian/patches/ef0cb9b4be572262b49fbc26fb2348683f44a517.patch:\n   try to fix testsuite failures on feh/powerpc.\n   (Closes: #812657)\n	1	89	2016-04-15 20:09:44+03		unstable
70	  * Non-maintainer upload.\n  * Fix DGifOpen(), uninitialized memory. Closes: #812093.\n	1	90	2016-01-27 03:00:16+03		unstable
71	  * Non-maintainer upload.\n  * New upstream version.\n    - CVE-2015-7555, Heap-based buffer overflow in giffix utility.\n     Closes: #808704.\n	2	91	2016-01-17 00:26:13+03	 CVE-2015-7555,	unstable
72	  * Non-maintainer upload, upload to unstable. Closes: #803158.\n	1	92	2015-12-12 18:13:06+03		unstable
73	  * Non-maintainer upload.\n  * New upstream version. See: #803158.\n  * Enable parallel builds.\n  * Build-depend on xmlto.\n  * Don't ship broken libungif symlinks. Closes: #732272. LP: #1337898.\n	1	93	2015-10-28 03:07:33+03		experimental
74	  * Remove Provides: libungif4g.\n  * Enable Multiarch (Closes: #647497).\n  * depend on dh-autoreconf.\n  * Update to debhelper 9 and bump Standards to 3.9.4.\n  * Honor the LAFileRemoval goal.\n  * Update git links.\n	3	94	2013-12-07 21:40:27+04		unstable
75	  * Fixing fprintf issues by YunQiang Su.\n  * Hardening build flags (Closes: #673660).\n  * Updating Standards (no change).\n	3	95	2012-10-20 01:03:46+04		unstable
76	  * Non-maintainer upload.\n  * Depend on libperl4-corelibs-perl (Closes: #659421)\n	3	96	2012-04-28 20:29:52+04		unstable
77	  * New Maintainer (Closes: #543841)\n  * Adding watch file (Closes: #453530)\n  * Converting to source package "3.0 (quilt)".\n  * Correcting debhelper version dependency.\n  * Adding Vcs fields.\n  * Adding manpages.\n  * Removing duplicate Section field.\n  * Correctly hyphenate man pages.\n  * Fixing spelling typos.\n  * Adding symbols file.\n  * Autoreconfiguring to fix rpath.\n  * Cleaning what autoreconf did.\n  * Registering html documentation.\n	3	97	2010-01-13 23:22:00+03		unstable
78	  * Updating package to standards version 3.8.3.\n  * Removing vcs fields.\n  * Orphaning package.\n	3	98	2009-08-27 09:25:21+04		unstable
79	  * Replacing obsolete dh_clean -k with dh_prep.\n  * Updating section of the debug package.\n  * Using quilt rather than dpatch.\n  * Using correct rfc-2822 date formats in changelog.\n  * Updating package to standards version 3.8.2.\n  * Removing old transitional packages.\n  * Adding misc depends to debug and development package.\n  * Updating year in copyright file.\n  * Minimizing rules file.\n	3	99	2009-07-27 15:12:16+04		unstable
80	  * Updating vcs fields in control file.\n  * Using patch-stamp rather than patch in rules file.\n  * Removing config.guess and config.sub in clean target of rules.\n * Passing '--disable-x11' to configure call to ensure that giflib is\n   not linked against X11 libs by accident (Closes: #503836).\n	3	100	2008-10-28 23:57:00+03		unstable
81	  * Correcting mistake of having libungif4-dev transitional package arch\n   dependent.\n  * Also adding libgif.so.4.1 symlink.\n  * Using links debhelper to create symlinks.\n  * Reordering rules file (Closes: #488586).\n  * Rewriting copyright file in machine-interpretable format.\n  * Adding vcs fields in control file.\n  * Upgrading package to standards .8.0.\n  * Upgrading package to debhelper 7.\n  * Reverting config.guess and config.sub to upstream.\n	3	101	2008-07-16 14:06:00+04		unstable
85	  * New upstream release.\n  * Bumped package to new policy.\n  * Using new homepage field in control.\n  * Don't hide make errors in clean target of rules.\n * Added --fail-missing to dh_install call.\n  * Updated conficts/replaces/provides to initiate libungif4 to libgif4\n   transition.\n	3	105	2008-01-17 20:34:00+03		unstable
86	  * Minor cleanups.\n	3	106	2007-01-19 16:14:00+03		unstable
87	  * Took over package from Pawel.\n  * New upstream release (Closes: #395388):\n    - This is giflib 4.x, replacing giflib 3.x. No package in the archive has to\n     be transitioned. After etch, giflib will replace libungif (all alleged patents\n     are expired all over the world).\n    - doesn't contain gif2x11 (Closes: #328665)\n    - isn't affected by CVE-2005-2974 and CVE-2005-3350 (Closes: #395382).\n  * Redone debian directory based on current debhelper templates, additionally:\n    - added watch file.\n    - added debug package.\n	3	107	2006-11-02 22:39:00+03	 CVE-2005-2974, CVE-2005-3350,	unstable
88	  * Applied patch from Dann Frazier <dannf@hp.com> to fix problems on 64-bit\n   archs (closes: #325034)\n  * Updated standards-version (no changes required)\n	3	108	2005-09-22 23:15:00+04		unstable
89	  * Updated copyright file by removing warning saying it cannot by put on CDs,\n    removed patent-related notes from long descriptions in control as well\n    (should have done that in -10, but forgot).\n	3	109	2004-08-19 02:43:34+04		unstable
90	  * Moved to main because of LZW's patent expiration (at long last!)\n   (closes: #258465)\n  * Fixed build-dependencies (closes: #262405)\n	3	110	2004-08-18 00:09:18+04		unstable
91	  * Renamed getarg.h to gagetarg.h, to avoid name clashes (closes: #83331)\n  * Updated standards version (no changes)\n	3	111	2004-01-20 00:47:34+03		unstable
92	  * Applied patch from John Lightsey <john@nixnuts.net> to fix transparency\n   problems (closes: #20716)\n  * Documented the fact, that giflib cannot be put on CD-ROMs (closes: #24580)\n  * Applied patch from John Lightsey <john@nixnuts.net> to fix gifinto's\n   behavior when no arguments are supplied (closes: #49431)\n  * giflib3g-dev now conflicts with heimdal-dev (closes: #83331, #180265)\n  * Updated standards version\n  * Updated sections (giflib3g-dev goes to non-free/libdevel, giflib3g-bin\n    goes to non-free/utils)\n	3	112	2003-06-18 15:54:09+04		unstable
93	  * New maintainer (closes: #139387)\n  * Upgraded to current standards version (closes: #133331)\n	3	113	2002-04-09 16:22:35+04		unstable
94	  * Move docs and man pages to /usr/share (Closes: #91165, #91479, #91480,\n   #91482)\n	3	114	2001-03-28 07:33:02+04		unstable
95	  * Redid debian/rules to use debhelper.\n  * Added symlinks so giflib can be used with packages compiled with\n   libungif.\n  * Added shlibs control file so that packages compiled with giflib can\n   also be used with libungif.\n	3	115	1998-07-06 09:46:51+04		unstable
96	  * Corrected bogus hardwired dependency on libc6.\n	3	116	1998-05-10 20:31:47+04		unstabl
97	  * Fixed copyright location(s)\n  * new maintainer address\n	3	117	1998-03-24 20:31:47+03		unstabl
98	  * libc6 release for hamm.\n	3	118	1997-10-18 14:25:32+04		unstable
99	  * renamed binaries to giflib* to bring them in sync with source name.\n	3	119	1997-09-29 20:11:22+04		unstable
100	  * fixed shared library. now link all bins with shared library.\n	3	120	1997-09-24 21:14:48+04		unstable
101	  * added -D_REENTRANT and -lc to cflags/ldflags for glibc2.\n	3	121	1997-09-18 16:26:06+04		unstable
103	  * Adapted for Strelets\n	1	2	2021-04-28 14:43:00+03		unstable
104	  * Non-maintainer upload.\n  * ldb_dn: avoid head corruption in ldb_dn_explode (CVE-2020-27840)\n   (Closes: #985936)\n  * pytests: move Dn.validate test to ldb\n  * ldb/attrib_handlers casefold: stay in bounds (CVE-2021-20277)\n   (Closes: #985935)\n  * ldb: add tests for ldb_wildcard_compare\n  * ldb tests: ldb_match tests with extra spaces\n  * ldb: Remove tests from ldb_match_test that do not pass\n	1	123	2021-03-26 21:52:18+03	 CVE-2020-27840, CVE-2021-20277,	unstable
105	  * Upload to unstable\n	1	124	2020-11-18 22:33:02+03		unstable
106	  * ldb_lmdb_free_list_test also fails on mips64el\n	1	125	2020-11-11 14:39:31+03		experimental
107	  * New upstream version 2.2.0\n    - d/watch: Bump to ldb 2.2.x, for samba 4.13.x\n    - Update patches\n    - Update symbols\n  * Generate python3-ldb.symbols to build on all python3 versions\n   (Closes: #972912)\n  * Update watch file format version to 4.\n  * d/copyright: Fix duplicate-globbing-patterns\n  * Move to debhelper-compat 13\n	1	126	2020-11-10 19:35:57+03		experimental
108	  * Also skip test_guid_indexed_v1_db on mipsel\n  * Also skip ldb_lmdb_free_list_test on ia64\n	2	127	2020-07-02 15:25:48+03		unstable
109	  * New upstream version 2.1.4\n    - CVE-2020-10730: NULL pointer de-reference and use-after-free in Samba AD\n     DC LDAP Server with ASQ, VLV and paged_results.\n    - Updade symbols, no change\n	2	128	2020-07-02 13:28:49+03	 CVE-2020-10730,	unstable
110	  * Upload to unstable\n  * Also skip ldb_lmdb_free_list_test on alpha\n	1	129	2020-06-28 12:28:16+03		unstable
111	  * FTBFS: Also skip test_guid_indexed_v1_db on powerpc\n  * FTBFS: Skip ldb_lmdb_free_list_test on ppc64el, ppc64 and sparc64\n	1	130	2020-06-25 16:16:24+03		experimental
112	  * Fix FTBFS / Increase the over-estimation for sparse files\n	1	131	2020-06-25 10:48:54+03		experimental
113	  * New upstream version 2.1.3\n    - d/watch: Move to 2.1.x for samba 4.12.x\n    - Update symbols\n    - d/control: Bump build-deps: talloc 2.3.1, tdb 1.4.3, tevent 0.10.2\n	1	132	2020-06-23 18:58:39+03		experimental
114	 [ Andreas Hasenack ]\n  * d/python3-ldb.symbols*: update symbols for python 3.8 (Closes: #953331)\n	1	133	2020-03-09 13:05:52+03		unstable
115	 [ Debian Janitor ]\n  * Use dh $@ sequencer.\n [ Mathieu Parent ]\n  * d/watch: Remove outdated dversionmangle\n  * d/watch: Pin to ldb 2.0.x (for samba 4.11)\n  * New upstream version 2.0.8\n    - Update symbols\n  * Standards-Version: 4.5.0, no change\n  * d/control: libldb-dev Depends libtevent-dev\n	1	134	2020-01-27 12:45:29+03		unstable
116	 [ Debian Janitor ]\n  * Update standards version to 4.4.1, no changes needed.\n [ Mathieu Parent ]\n  * Only build on default python3 (Closes: #942669)\n	1	135	2019-11-17 16:42:51+03		unstable
117	  * Fix FTBFS on some arches:\n    - Skip test_guid_indexed_v1_db on mips64el, ppc64el, ia64, ppc64\n	1	136	2019-10-02 22:26:49+03		unstable
118	 [ Jelmer Vernooĳ ]\n  * Remove obsolete fields Name, Contact from debian/upstream/metadata.\n  * Rely on pre-initialized dpkg-architecture variables.\n [ Mathieu Parent ]\n  * Upload to unstable\n	1	137	2019-10-02 08:07:59+03		unstable
119	  * Upload to experimental\n  * New upstream version 2.0.7\n    - d/watch: Unpin ldb to 1.4.x\n    - d/control: Bump build-deps: talloc 2.2.0, tdb 1.4.2, tevent 0.10.0\n    - Drop 00_Enable-make-test-even-without-lmdb.patch, merged\n    - Replace libldb1 by libldb2 (ABI Bump)\n    - Update symbols\n	1	138	2019-09-16 14:59:24+03		experimental
120	  * Upload to unstable\n  * d/copyright:\n    - Move common/qsort.c as if it was lib/ldb/common/qsort.c\n    - Move tools/* as if it was lib/ldb/tools/*\n    - Sort lib/{talloc,tdb,tevent}\n	1	139	2019-09-10 19:21:30+03		unstable
121	 [ Mathieu Parent ]\n  * New upstream version 1.5.5\n  * Update salsa-ci.yml\n [ Timo Aaltonen ]\n  * d/p/00_Enable-make-test-even-without-lmdb.patch: Refreshed.\n  * d/p/03_EBADE: Dropped, upstream.\n  * d/control: Bump build-deps: talloc 2.1.16, tdb 1.3.18, tevent 0.9.39.\n  * d/libldb1.install: added libldb-tdb-{err-map,int}.so\n  * d/rules: use Makefile targets instead of direct WAF calls\n  * Add python3 packages.\n  * d/control, d/python3-ldb-dev.install, d/rules: use dh-exec and install the\n    python header file in a version-dependent include dir.\n  * d/python3-ldb.symbols.*: add per-architecture symbols files\n  * d/libldb1.symbols: update for this version\n  * d/rules: clean extra paths in the clean target\n  * d/rules: fix tevent globbing used in its removal\n  * d/control, d/python-ldb*, d/rules: drop python2 packages and support\n [ Debian Janitor ]\n  * Use secure URI in Homepage field.\n  * Bump debhelper from old 11 to 12.\n  * Set upstream metadata fields: Contact, Name.\n [ Mathieu Parent ]\n  * Fix file-contains-trailing-whitespace in d/control and d/rules\n  * Standards-Version: 4.4.0\n  * Override wrong-section-according-to-package-name python3-ldb-dev => python\n  * Mark debian/python3-ldb-dev.install executable\n  * Override package-name-doesnt-match-sonames libpyldb-util.cpython-*\n  * d/copyright: Add waf copyright\n  * d/copyright: Update lib/replace/*\n  * d/copyright: Add missing lib/talloc/*\n  * Add dh-exec-subst-unknown-variable override (for DEB_PY3_INCDIR)\n	1	140	2019-08-24 07:37:58+03		experimental
122	 [ Salsa Pipeline ]\n  * Update salsa CI pipeline\n [ Mathieu Parent ]\n  * New upstream version 1.4.7\n    - Update symbols (no change)\n	1	141	2019-07-07 11:06:38+03		unstable
123	  * Upload to unstable\n	1	142	2019-03-30 20:09:28+03		unstable
124	  * Fix 00_Enable-make-test-even-without-lmdb.patch to prevent FTBFS on 32-bit\n   systems\n	1	143	2019-03-20 22:54:20+03		experimental
125	  * New upstream version 1.4.6\n    - d/watch: Pin ldb version to 1.4.x\n    - d/watch: Mangle 1.5.1+really from debian version\n    - Update 00_Enable-make-test-even-without-lmdb.patch as merged upstream\n    - Drop CVE-2019-3824-v4-9.patch, merged\n    - Update symbols\n	1	144	2019-03-20 09:26:57+03	 CVE-2019-3824,	experimental
126	  * Fixes CVE-2019-3824: "Out of bound read in ldb_wildcard_compare"\n    - Add CVE-2019-3824-v4-9.patch\n    - Update path, and remove version bump in CVE-2019-3824-v4-9.patch\n	2	145	2019-02-27 01:50:07+03	 CVE-2019-3824, CVE-2019-3824, CVE-2019-3824,	unstable
127	  * Rollback to version 1.4.3 (for Samba 4.9)\n    - Revert "Refresh symbols files."\n    - Revert "Install libldb-tdb-{err-map,int}.so"\n    - Revert "Drop patch 03_EBADE: applied upstream."\n	2	146	2018-11-25 00:50:47+03		unstable
128	  * New upstream release.\n  * Drop patch 03_EBADE: applied upstream.\n  * Install libldb-tdb-{err-map,int}.so\n  * Unicodify my surname.\n	1	147	2018-11-23 16:35:28+03		unstable
129	  * Upload to unstable\n	1	148	2018-11-17 19:26:26+03		unstable
130	  * Upload to experimental\n  * New upstream version 1.4.3\n    - Update symbols: no change\n  * Add Debian pipeline (debian/gitlab-ci.yml\n  * Lintian:\n    - debian/python-ldb.lintian-overrides: Override false-positive\n      library-not-linked-against-libc\n    - Fix public-upstream-key-not-minimal\n    - Add Build-Depends-Package field in d/*.symbols\n	1	149	2018-11-12 11:07:14+03		experimental
131	 [ James Clarke ]\n  * 03_EBADE: Add patch from upstream to fix FTBFS on architectures with no\n   EBADE error code, such as GNU/kFreeBSD.\n [ Mathieu Parent ]\n  * Upload to unstable\n	1	150	2018-11-01 23:10:06+03		unstable
132	  * Fix FTBFS on 32-bit architectures (Samba #13630):\n    - Revert "d/rules: Append -D_FILE_OFFSET_BITS=64 to CFLAGS to fix FTBFS on\n      32-bit platforms"\n    - Enable make test even without lmdb\n    - 02_hurd patch fixup\n    - d/libldb1.install: Do not ship libldb-mdb-int.so on 32-bit architectures\n	1	151	2018-10-08 15:31:20+03		experimental
133	  * d/rules: Append -D_FILE_OFFSET_BITS=64 to CFLAGS to fix FTBFS on 32-bit\n   platforms\n  * d/rules: More verbose build log with waf -v\n	1	152	2018-09-19 07:44:59+03		experimental
134	  * Upload to experimental\n  * New upstream version 1.4.2\n    - Bump build-dependencies to talloc 2.1.4, tdb 1.3.16 and tevent 0.9.37\n    - Update symbols\n    - Update patch 02_hurd\n  * d/rules: Remove dbgsym-migration in override_dh_strip\n  * d/libldb1.install: Install libldb-mdb-int.so and libldb-key-value.so\n * d/rules: dh_missing --fail-missing\n  * d/control: Revert "Mark python-ldb Multi-Arch: same" to fix Lintian's\n    multi-arch-same-package-calls-pycompile\n	1	153	2018-09-18 22:21:53+03		experimental
135	  * New upstream version 1.3.6\n    - Update symbols, no change\n    - Remove 03_ldb-Fix-missing-NULL-terminator-in-ldb_mod_op_test-t.patch,\n     merged\n  * Standards-Version: 4.2.1\n	1	154	2018-08-27 16:11:58+03		unstable
136	  * Add patch from upstream to fix FTBFS on some arches (arm64, armhf, mips,\n   mipsel, s390x, ...)\n  * Urgency kept to high\n	2	155	2018-08-16 16:46:12+03		unstable
137	  * Upload to unstable\n  * Urgency high for 4.8.4 security release\n  * New upstream version 1.3.5 (for samba 4.8.4)\n    - samba 4.8 is not compatible with ldb 1.4\n    - Update symbols, no change\n    - Update patches\n  * Revert python3 support until it is back in talloc (Reopen: #815139)\n  * Standards-Version: 4.1.5\n    - d/control: Add Rules-Requires-Root: no\n	2	156	2018-08-15 06:13:16+03		unstable
138	 [ Timo Aaltonen ]\n  * Add py3 support (Closes: #815139)\n [ Louis van Belle ]\n  * Relax debhelper Build-Depends to allow backport\n [ Mathieu Parent ]\n  * New upstream version 1.4.0\n    - Bump build-dependencies to talloc 2.1.13\n    - Update symbols, no change\n    - Add liblmdb-dev (>= 0.9.16) to Build-Depends\n    - Update patches\n	1	157	2018-07-01 22:52:39+03		experimental
139	  * New upstream version 1.3.3\n    - Update symbols, no change\n  * Standards-Version: 4.1.4, no change\n	1	158	2018-05-17 00:46:56+03		unstable
140	  * Upload to unstable\n	3	159	2018-05-15 16:43:04+03		unstable
141	  * New upstream version 1.3.2\n    - Bump build-dependencies to talloc 2.1.11 and tevent 0.9.36\n    - Update symbols\n  * Upload to experimental\n	1	160	2018-03-11 23:36:00+03		experimental
142	  * New upstream version 1.2.3\n    - Update symbols (no change)\n  * Standards-Version: 4.1.3, no change\n  * Repository moved to salsa: Update Vcs-* fields\n  * Bumping debhelper compat from 9 to 11\n	1	161	2018-01-11 09:36:33+03		unstable
143	  * Upload to sid\n	1	162	2017-10-26 11:28:05+03		unstable
144	  * New upstream version 1.2.2\n    - Update symbols\n    - Bump build-dependencies to talloc 2.1.10, tdb 1.3.15 and tevent 0.9.33\n    - Add Breaks to incompatible packages\n    - Add Build-Depends: libcmocka-dev (>= 1.1.1~)\n  * Use https form of the copyright-format URL (Debian Policy 4.0.0)\n  * Standards-Version: 4.0.0\n	1	163	2017-10-03 22:44:15+03		experimental
145	  * Upload to unstable\n	1	164	2017-06-19 18:25:13+03		unstable
187	  * New upstream snapshot.\n  * Support older versions of tdb.\n	3	206	2010-09-08 05:53:47+04		experimental
188	  * New upstream snapshot.\n    + Builds against system default Python rather than most recent supported\n     python. Closes: #577436.\n  * Bump standards version to 3.9.1.\n  * Switch to Bazaar.\n	3	207	2010-08-22 17:18:28+04		experimental
189	  * New upstream snapshot.\n	3	208	2010-07-30 17:40:04+04		maverick
146	 [ Jelmer Vernooĳ ]\n  * New upstream release.\n    - Update symbols\n    - Bump tdb and tevent Build-depends (resp. 1.3.12 and 0.9.31)\n [ Mathieu Parent ]\n  * gbp.conf: pristine-tar = True\n  * New upstream version 1.1.29\n  * Thanks lintian:\n    - Debhelper compat 9\n    - Fix missing-build-dependency-for-dh_-command dh_python2 => dh-python\n      + Update symbols, again\n    - Remove unused overrides: ldb-tools/python-ldb:\n      binary-or-shlib-defines-rpath * /usr/lib/ldb\n    - Remove empty libldb1.postinst\n    - Hardening: Add DEB_BUILD_MAINT_OPTIONS = hardening=+all and\n     DEB_LDFLAGS_MAINT_APPEND = -Wl,--as-needed\n    - Add override for python-ldb-dev: wrong-section-according-to-package-name\n    - Add missing header and fix d/copyright\n    - Mark python-ldb Multi-Arch: same\n	1	165	2017-06-11 00:03:32+03		experimental
147	  * New upstream version.\n    - Bump Buid-Depends: talloc 2.1.8, tdb 1.3.10 and tevent 0.9.29\n    - Update symbols\n  * Use secure Vcs-* uris (Closes: #805719)\n  * Add me to uploaders\n  * Bump standards version to 3.9.8 (no changes)\n  * Use automatic debug packages (-dbgsym)\n  * Mark libldb-dev and python-ldb-dev "Multi-Arch: same"\n	1	166	2016-10-10 11:02:53+03		unstable
148	  * New upstream version.\n   + Fixes compatiblity with s390. Closes: #808769\n   + Depend on tevent 0.9.27.\n	1	167	2016-02-26 06:18:59+03		unstable
149	  * Drop '-b unstable' flag to Vcs-Git.\n  * New upstream release. Fixes:\n  - CVE-2015-3223: Denial of Service.\n  - CVE-2015-5330: Remote memory read.\n	2	168	2015-12-13 19:11:45+03	 CVE-2015-3223, CVE-2015-5330,	unstable
150	  * New upstream version.\n	1	169	2015-11-09 00:17:41+03		unstable
151	  * New upstream release.\n  * Drop patch 03_revert_ldflags_atend: applied upstream.\n	1	170	2015-09-19 06:01:43+03		unstable
152	  * Add patch 01_manpage_dates: add fixed manpage dates, making the\n   build reproducible.\n	1	171	2015-04-28 02:35:02+03		unstable
153	  * New upstream release.\n  * Bump standards version to 3.9.6 (no changes).\n  * Add patch 03_revert_ldflags_atend: revert upstream change preventing\n   use of -Wl,--as-needed.\n  * Make libldb1-dbg Multi-Arch: same.\n  * python-ldb-dev: Fix capitalization of 'python'.\n	1	172	2015-04-25 17:13:06+03		unstable
154	  * No changes from 1:1.1.17-1 (currently in jessie)\n  * Increment epoch to revert upload of 1:1.1.18-1 to unstable\n  * Urgency high to allow samba security upload to migrate to jessie\n	2	173	2015-02-23 21:03:36+03		unstable
155	  * New upstream release.\n   + Depend on tdb >= 1.3.2.\n   + Fixes __attribute__((visibility)) check to not use nested functions.\n    Closes: #749987\n  * Use canonical URL in Vcs-Git field.\n  * Specify branch in Vcs-Git field.\n  * Add 02_hurd: link against pthread on the Hurd, to fix ldb module\n   loading. Closes: #749095\n	1	174	2014-07-06 01:32:23+04		unstable
156	  * Change maintainer to Debian Samba maintainers, move myself to\n   uploaders.\n  * Bump standards version to 3.9.5 (no changes).\n  * New upstream release.\n	1	175	2014-04-12 18:10:56+04		unstable
157	 [ Andrew Bartlett ]\n  * New upstream release.\n    + Fixes FTBFS. Closes: #713096\n [ Jelmer Vernooij ]\n  * Bump standards version to 3.9.4 (no changes).\n	3	176	2013-07-19 16:37:05+04		unstable
158	  * Non-maintainer upload.\n  * New upstream release.\n  * Drop 01_exclude_symbols, now upstream.\n	3	177	2013-02-12 12:02:05+04		experimental
159	  * New upstream release.\n  * Change Vcs-Git after migration to Git.\n  * Add 01_exclude_symbols, fixing a bug in wafsamba which causes\n   private symbols to be exported.\n	3	178	2012-11-03 18:51:49+04		experimental
160	  * New upstream release.\n   + Depend on tevent 0.9.17.\n	3	179	2012-09-08 19:40:55+04		experimental
161	  * New upstream release.\n	3	180	2012-04-19 17:00:14+04		unstable
162	  * Add explicit dependency on tdb 1.2.10. Closes: #668576\n	3	181	2012-04-13 13:14:29+04		unstable
163	  * Bump standards version to 3.9.3 (no changes).\n  * Drop unnecessary lintian overrides (upstream no longer uses private\n   libraries with rpath).\n  * Properly clean up after build.\n  * New upstream release.\n	3	182	2012-04-12 03:46:01+04		unstable
164	  * New upstream snapshot.\n   + Extracts waf source code. Closes: #654482\n   + Disable tdb2 support.\n	3	183	2012-02-07 19:04:26+04		unstable
165	  * New upstream release.\n	3	184	2011-12-03 03:15:12+04		unstable
166	  * New upstream release.\n	3	185	2011-11-09 17:17:14+04		unstable
167	  * Explicitly build with dh_python2.\n  * Build against system Python rather than specifically 2.7. Closes: #642436\n	3	186	2011-09-27 21:49:00+04		unstable
168	  * New upstream snapshot.\n   + Adds proper symbol versioning to libpyldb-util. LP: #777517\n	3	187	2011-08-07 18:06:59+04		unstable
169	  * Upload to unstable.\n  * Switch to new style debhelper.\n  * New upstream snapshot.\n	3	188	2011-07-28 18:51:49+04		unstable
170	  * Add multi-arch support to libldb1.\n  * Add debug packages python-ldb-dbg and libldb1-dbg.\n	3	189	2011-07-27 00:08:11+04		experimental
171	  * Switch to python2.7.\n	3	190	2011-07-25 19:41:20+04		unstable
172	  * Fix build dependency to be on tevent 0.9.13 rather than 0.9.11. Thanks\n   Nobuhiro Iwamatsu.\n	3	191	2011-07-21 18:24:08+04		unstable
173	  * New upstream snapshot.\n  * Bump standards version to 3.9.2 (no changes).\n	3	192	2011-07-19 23:45:21+04		unstable
174	  * New upstream release.\n	3	193	2011-04-22 04:58:49+04		unstable
175	  * New upstream snapshot.\n  * Switch to dh_python2. Closes: #616857\n	3	194	2011-04-03 23:51:32+04		experimental
176	  * Add symbols file for libpyldb-util.\n	3	195	2011-02-28 06:02:31+03		unstable
177	  * New upstream release.\n	3	196	2011-02-27 16:29:46+03		unstable
178	  * New upstream snapshot.\n	3	197	2011-02-20 16:42:57+03		experimental
179	  * Add breaks/conflicts for libldb0.\n	3	198	2011-02-12 20:23:07+03		unstable
180	  * Run test suite during package build.\n  * Add references to common license files in copyright file.\n  * New upstream release.\n   + Rename libldb0 to libldb1 after upstream soname bump.\n	3	199	2011-02-12 05:45:51+03		unstable
181	  * New upstream release.\n   + Add python-ldb-dev package.\n  * Add watch file.\n	3	200	2010-10-23 22:00:40+04		experimental
182	  * New upstream release.\n   + Add python-ldb-dev package.\n   + Uses version symbols.\n  * Switch to python-support.\n * Link with --as-needed.\n  * Run test suite during build.\n	3	201	2010-12-22 02:05:26+03		experimental
183	  * New upstream release.\n   + Add python-ldb-dev package.\n   + Uses version symbols.\n  * Switch to python-support.\n * Link with --as-needed.\n  * Run test suite during build.\n	3	202	2010-12-22 02:05:26+03		unstable
184	  * New upstream snapshot.\n   + Use alternatives to manage new /usr/lib/ldap.so link.\n  * OpenLDAP support is now always built.\n  * Fixes references to ldb(3) in manpages. Closes: #584227\n  * Override modules directory to be /usr/lib/ldb, rather\n   than /usr/modules/ldb as is now the upstream default. Closes: #600824\n	3	203	2010-10-13 18:45:29+04		unstable
185	  * Support talloc 2.0.1.\n  * New upstream snapshot.\n	3	204	2010-09-13 17:11:46+04		unstable
186	  * Support tdb 1.2.1.\n	3	205	2010-09-10 19:17:40+04		experimental
193	  * New upstream snapshot.\n	3	212	2010-05-23 17:50:20+04		experimental
194	  * New upstream snapshot.\n  * Bump standards version to 3.8.4.\n  * Switch to dpkg-source 3.0 (quilt) format\n	3	213	2010-02-03 18:16:48+03		unstable
195	  * New upstream version.\n  * Depend on libtdb-dev rather than tdb-dev.\n	3	214	2009-12-13 00:04:36+03		unstable
196	  * New upstream snapshot.\n	3	215	2009-09-12 01:34:22+04		unstable
197	  * Remove unused patch.\n  * Bump standards version to 3.8.3.\n	3	216	2009-09-12 00:49:46+04		unstable
198	  * New upstream snapshot.\n  * Bump standards version to 3.8.2.\n  * Link Python modules only against necessary libraries.\n	3	217	2009-07-18 12:55:47+04		unstable
199	  * New upstream snapshot.\n  * Bump standards version to 3.8.1.\n	3	218	2009-07-17 22:37:51+04		unstable
200	  * New upstream snapshot.\n  * Switch to python-central.\n  * Add dummy watch file explaining how to obtain an upstream tarball.\n  * Build against tevent.\n * Compile with -Wl,--as-needed.\n	3	219	2009-01-01 08:47:33+03		unstable
201	  * Fix version number accidently messed up by typo earlier.\n  * Fix copyright listing.\n  * Fix dependency of python-ldb on libc.\n	3	220	2008-07-27 17:58:54+04		unstable
202	  * New upstream snapshot.\n  * Add patch to remove dependency on events lib in pkg-config file,\n   which is not packaged yet.\n	3	221	2008-06-16 23:00:43+04		unstable
203	  * Add dependency on tdb-dev to libldb-dev.\n  * New upstream snapshot.\n  * Bump standards version to 3.8.0.\n	3	222	2008-06-15 21:26:38+04		unstable
204	  * New upstream snapshot.\n	3	223	2008-05-20 04:54:45+04		unstable
205	  * New upstream snapshot.\n	3	224	2008-01-22 18:50:02+03		unstable
206	  * Set Vcs-Svn field.\n  * Fix building twice in a row. (Closes: #442625)\n  * New upstream snapshot.\n	3	225	2007-12-04 21:47:13+03		unstable
207	  * Improve long description a bit. (Closes: #438657)\n  * Set homepage field.\n  * New upstream snapshot.\n  * Add python-ldb package.\n  * Allow Debian Maintainer uploads.\n	3	226	2007-11-25 19:29:17+03		unstable
208	  * Put libldb-dev in libdevel section. (Closes: #427582)\n  * Don't build shared version of ldbadd. (Closes: #427527)\n  * Use ${binary:Version} rather than obsolete ${Source-Version}.\n	3	227	2007-06-07 00:59:28+04		unstable
\.


--
-- Data for Name: package; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.package (pkg_id, pkg_name) FROM stdin;
1	giflib
2	ldb
3	libraw
4	libgif7-dbgsym
5	giflib-tools-dbgsym
6	libgif7
7	giflib-tools
8	libgif-dev
9	python3-ldb
10	ldb-tools
11	python3-ldb-dbgsym
12	python3-ldb-dev
13	libldb-dev
14	ldb-tools-dbgsym
15	libldb2
16	libldb2-dbgsym
17	libraw-dev
18	libraw-bin-dbgsym
19	libraw20-dbgsym
20	libraw-doc
21	libraw20
22	libraw-bin
\.


--
-- Data for Name: pkg_version; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.pkg_version (pkg_vrs_id, pkg_date_created, author_name, pkg_id, version) FROM stdin;
1	\N	Mikhail Mirkin <info@nppct.ru>	1	5.1.9-2osnova1
2	\N	Andrey Shumilin <support@nppct.ru>	2	2:2.2.0-3.1osnova0
3	\N	Mikhail Mirkin <info@nppct.ru>	3	0.20.2-1.osnova1
4	\N	\N	4	5.1.9-2osnova1
5	\N	\N	5	5.1.9-2osnova1
6	\N	\N	6	5.1.9-2osnova1
7	\N	\N	7	5.1.9-2osnova1
8	\N	\N	8	5.1.9-2osnova1
9	\N	\N	9	2.2.0-3.1osnova0
10	\N	\N	10	2.2.0-3.1osnova0
11	\N	\N	11	2.2.0-3.1osnova0
12	\N	\N	12	2.2.0-3.1osnova0
13	\N	\N	13	2.2.0-3.1osnova0
14	\N	\N	14	2.2.0-3.1osnova0
15	\N	\N	15	2.2.0-3.1osnova0
16	\N	\N	16	2.2.0-3.1osnova0
17	\N	\N	17	0.20.2-1.osnova1
18	\N	\N	18	0.20.2-1.osnova1
19	\N	\N	19	0.20.2-1.osnova1
20	\N	\N	20	0.20.2-1.osnova1
21	\N	\N	21	0.20.2-1.osnova1
22	\N	\N	22	0.20.2-1.osnova1
23	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.20.2-1
24	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.20.0-4
25	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.20.0-3
26	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.20.0-2
27	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.20.0-1
28	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.5-1
29	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.4-1
30	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.3-1
31	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.2-2
32	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.2-1
33	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.1-1
34	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.0-4
35	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.0-3
36	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.0-2
37	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.19.0-1
38	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.13-1
39	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.11-1
40	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.8-2
41	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.8-1
42	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.7-2
43	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.7-1
44	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.6-1
45	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.5-1
46	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.2-2
47	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.2-1
48	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.1-1
49	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.18.0-1
50	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-6
51	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-5
52	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-4
53	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-3
54	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-2
55	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.2-1
56	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.1-1
57	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.17.0-1
58	\N	Matteo F. Vescovi <mfv@debian.org>	3	0.16.2-1
59	\N	Matteo F. Vescovi <mfvescovi@gmail.com>	3	0.16.0-9
60	\N	Matteo F. Vescovi <mfvescovi@gmail.com>	3	0.16.0-8
61	\N	Matteo F. Vescovi <mfvescovi@gmail.com>	3	0.16.0-7
62	\N	Matteo F. Vescovi <mfvescovi@gmail.com>	3	0.16.0-6
63	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.16.0-5
64	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.16.0-4
65	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.16.0-3
66	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.16.0-2
67	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.16.0-1
68	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.15.4-1
69	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.15.3-1
70	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.15.1-1
71	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.14.7-2
72	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.14.7-1
73	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.14.6-2
74	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.14.6-1
75	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.14.0-1
76	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.13.8-1
77	\N	Devid Antonio Filoni <d.filoni@ubuntu.com>	3	0.13.1-2
78	\N	Luca Falavigna <dktrkranz@debian.org>	3	0.13.1-1
80	\N	David Suárez <david.sephirot@gmail.com>	1	5.1.9-2
81	\N	David Suárez <david.sephirot@gmail.com>	1	5.1.9-1
82	\N	Salvatore Bonaccorso <carnil@debian.org>	1	5.1.4-3
83	\N	Andreas Metzler <ametzler@debian.org>	1	5.1.4-2
84	\N	Andreas Metzler <ametzler@debian.org>	1	5.1.4-1
85	\N	Paolo Greppi <paolo.greppi@libpf.com>	1	5.1.4-0.4
86	\N	Matthias Klose <doko@debian.org>	1	5.1.4-0.3
87	\N	Matthias Klose <doko@debian.org>	1	5.1.4-0.2
88	\N	Matthias Klose <doko@debian.org>	1	5.1.4-0.1
89	\N	Gianfranco Costamagna <locutusofborg@debian.org>	1	5.1.2-0.3
90	\N	Matthias Klose <doko@debian.org>	1	5.1.2-0.2
91	\N	Matthias Klose <doko@debian.org>	1	5.1.2-0.1
92	\N	Matthias Klose <doko@debian.org>	1	5.1.1-0.2
93	\N	Matthias Klose <doko@debian.org>	1	5.1.1-0.1
94	\N	Thibaut Gridel <tgridel@free.fr>	1	4.1.6-11
95	\N	Thibaut Gridel <tgridel@free.fr>	1	4.1.6-10
96	\N	Dominic Hargreaves <dom@earth.li>	1	4.1.6-9.1
97	\N	Thibaut GRIDEL <tgridel@free.fr>	1	4.1.6-9
98	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-8
99	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-7
100	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-6
101	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-5
102	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-4
103	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-3
104	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-2
105	\N	Daniel Baumann <daniel@debian.org>	1	4.1.6-1
106	\N	Daniel Baumann <daniel@debian.org>	1	4.1.4-2
107	\N	Daniel Baumann <daniel@debian.org>	1	4.1.4-1
108	\N	Pawel Wiecek <coven@debian.org>	1	3.0-12
109	\N	Pawel Wiecek <coven@debian.org>	1	3.0-11
110	\N	Pawel Wiecek <coven@debian.org>	1	3.0-10
111	\N	Pawel Wiecek <coven@debian.org>	1	3.0-9
112	\N	Pawel Wiecek <coven@debian.org>	1	3.0-8
113	\N	Pawel Wiecek <coven@debian.org>	1	3.0-7
114	\N	Larry Daffner <vizzie@airmail.net>	1	3.0-6
115	\N	Jim Pick <jim@jimpick.com>	1	3.0-5.2
116	\N	Michael Alan Dorman <mdorman@debian.org>	1	3.0-5.1
117	\N	Larry Daffner <vizzie@airmail.net>	1	3.0-5
118	\N	Andreas Jellinghaus <aj@dungeon.inka.de>	1	3.0-4.1
119	\N	Andreas Jellinghaus <aj@dungeon.inka.de>	1	3.0-4
120	\N	Andreas Jellinghaus <aj@dungeon.inka.de>	1	3.0-3
121	\N	Andreas Jellinghaus <aj@dungeon.inka.de>	1	3.0-2
123	\N	Salvatore Bonaccorso <carnil@debian.org>	2	2:2.2.0-3.1
124	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.2.0-3
125	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.2.0-2
126	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.2.0-1
127	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.4-2
128	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.4-1
129	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.3-4
130	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.3-3
131	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.3-2
132	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.1.3-1
133	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.8-2
134	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.8-1
135	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.7-4
136	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.7-3
137	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.7-2
138	\N	Mathieu Parent <sathieu@debian.org>	2	2:2.0.7-1
139	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.5-2
140	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.5-1
141	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.7-1
142	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.6-3
143	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.6-2
144	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.6-1
145	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.3-2
146	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.5.1+really1.4.3-1
147	\N	Jelmer Vernooĳ <jelmer@debian.org>	2	2:1.5.1-1
148	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.3-2
149	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.3-1
150	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.2-4
151	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.2-3
152	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.2-2
153	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.2-1
154	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.0+really1.3.6-1
155	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.0+really1.3.5-2
156	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.0+really1.3.5-1
157	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.4.0-1
158	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.3.3-1
159	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.3.2-2
160	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.3.2-1
161	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.2.3-1
162	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.2.2-2
163	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.2.2-1
164	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.1.29-2
165	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.1.29-1
166	\N	Mathieu Parent <sathieu@debian.org>	2	2:1.1.27-1
167	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.26-1
168	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.24-1
169	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.23-1
170	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.21-1
171	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.20-2
172	\N	Jelmer Vernooij <jelmer@debian.org>	2	2:1.1.20-1
173	\N	Ivo De Decker <ivodd@debian.org>	2	2:1.1.17-2
174	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.18-1
175	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.17-1
176	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.16-1
177	\N	Andrew Bartlett <abartlet@samba.org>	2	1:1.1.15-1.1
178	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.13-1
179	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.12-1
180	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.6-1
181	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.5-2
182	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.5-1
183	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.4+git20120206-1
184	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.4-1
185	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.3-1
186	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.2~git20110807-2
187	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.2~git20110807-1
188	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.1~git20110728-1
189	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.1~git20110719-4
190	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.1~git20110719-3
191	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.1~git20110719-2
192	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.1~git20110719-1
193	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.1.0-1
194	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.2+git20110403-1
195	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.2-2
196	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.2-1
197	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.1~git20120220-1
198	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.0-2
199	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:1.0.0-1
200	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.24-1
201	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.22-2
202	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.22-1
203	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.16~git20101019-1
204	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.14~git20100928-1
205	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.13~git20100908-2
206	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.13~git20100908-1
207	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.13~git20100820-1
208	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.13~git20100730-1
209	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.12~git20100615-1
210	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.11~git20100531-1
211	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.10~git20100531-1
212	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.10~git20100522-1
213	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.10~git20100203-1
214	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.10~git20091212-1
215	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.6~git20090912-1
216	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.6~git20090718-2
217	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.6~git20090718-1
218	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.6~git20090617-1
219	\N	Jelmer Vernooij <jelmer@debian.org>	2	1:0.9.3~git20090221-1
220	\N	Jelmer Vernooij <jelmer@samba.org>	2	1:0.9.2~git20080616-1
221	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.92~git20080616-1
222	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.2~git20080615-1
223	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.2~git20080520-1
224	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.2~git20080122-1
225	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.1~svn26291-1
226	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.1~svn26185-1
227	\N	Jelmer Vernooij <jelmer@samba.org>	2	0.9.0-2
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.project (prj_id, prj_name, rel_id, prj_desc, vendor, arch_id) FROM stdin;
1	onyx	\N	\N	\N	\N
\.


--
-- Data for Name: release; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.release (rel_id, rel_name) FROM stdin;
\.


--
-- Data for Name: urgency; Type: TABLE DATA; Schema: repositories; Owner: owner
--

COPY repositories.urgency (urg_id, urg_name) FROM stdin;
1	medium
2	high
3	low
\.


--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.cwe_cwe_id_seq', 1, false);


--
-- Name: identifier_ident_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.identifier_ident_id_seq', 1, false);


--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vul_ident_vul_id_seq', 1, false);


--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vul_sources_vul_src_id_seq', 1, false);


--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vulnerability_vul_id_seq', 1, false);


--
-- Name: cve_cve_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.cve_cve_id_seq', 1, false);


--
-- Name: package_pkg_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.package_pkg_id_seq', 1, false);


--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.pkg_version_pkg_vrs_id_seq', 1, false);


--
-- Name: release_rel_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.release_rel_id_seq', 1, false);


--
-- Name: repository_rep_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.repository_rep_id_seq', 1, false);


--
-- Name: status_st_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.status_st_id_seq', 1, false);


--
-- Name: urgency_urg_id_seq; Type: SEQUENCE SET; Schema: debtracker; Owner: owner
--

SELECT pg_catalog.setval('debtracker.urgency_urg_id_seq', 1, false);


--
-- Name: architecture_arch_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.architecture_arch_id_seq', 1, false);


--
-- Name: assembly_assm_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.assembly_assm_id_seq', 1, true);


--
-- Name: changelog_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.changelog_id_seq', 208, true);


--
-- Name: package_pkg_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.package_pkg_id_seq', 22, true);


--
-- Name: pkg_version_pkg_vrs_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.pkg_version_pkg_vrs_id_seq', 227, true);


--
-- Name: project_prj_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.project_prj_id_seq', 1, true);


--
-- Name: release_rel_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.release_rel_id_seq', 1, false);


--
-- Name: urgency_urg_id_seq; Type: SEQUENCE SET; Schema: repositories; Owner: owner
--

SELECT pg_catalog.setval('repositories.urgency_urg_id_seq', 3, true);


--
-- Name: vul_cwe vul_cwe_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_pkey PRIMARY KEY (vul_id, cwe_id);


--
-- Name: vul_ident vul_ident_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_pkey PRIMARY KEY (vul_id, ident_id);


--
-- Name: cve_rep cve_rep_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_pkey PRIMARY KEY (cve_id, rep_id);


--
-- Name: pkg_version_version_pkg_id_idx; Type: INDEX; Schema: debtracker; Owner: owner
--

CREATE INDEX pkg_version_version_pkg_id_idx ON debtracker.pkg_version USING btree (version, pkg_id);


--
-- Name: assm_pkg_vrs assm_pkg_vrs_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assm_pkg_vrs
    ADD CONSTRAINT assm_pkg_vrs_pkey PRIMARY KEY (assm_id, pkg_vrs_id);


--
-- Name: assm_pkg_vrs unique_assm_pkg_vrs_assm_id_pkg_vrs_id; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assm_pkg_vrs
    ADD CONSTRAINT unique_assm_pkg_vrs_assm_id_pkg_vrs_id UNIQUE (assm_id, pkg_vrs_id);


--
-- Name: pkg_version unique_pkg_version_version_pkg_id; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.pkg_version
    ADD CONSTRAINT unique_pkg_version_version_pkg_id UNIQUE (version, pkg_id);


--
-- Name: project unique_project_prj_name_rel_id_arch_id; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.project
    ADD CONSTRAINT unique_project_prj_name_rel_id_arch_id UNIQUE (prj_name, rel_id, arch_id);


--
-- Name: cwe cwe_cwe_name_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe
    ADD CONSTRAINT cwe_cwe_name_key UNIQUE (cwe_name);


--
-- Name: cwe cwe_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe
    ADD CONSTRAINT cwe_pkey PRIMARY KEY (cwe_id);


--
-- Name: vulnerability fstek_element_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability
    ADD CONSTRAINT fstek_element_pkey PRIMARY KEY (vul_id);


--
-- Name: identifier identifier_ident_name_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier
    ADD CONSTRAINT identifier_ident_name_key UNIQUE (ident_name);


--
-- Name: identifier identifiers_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier
    ADD CONSTRAINT identifiers_pkey PRIMARY KEY (ident_id);


--
-- Name: vul_sources vul_sources_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources
    ADD CONSTRAINT vul_sources_pkey PRIMARY KEY (vul_src_id);


--
-- Name: vulnerability vulnerability_vul_ident_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability
    ADD CONSTRAINT vulnerability_vul_ident_key UNIQUE (vul_ident);


--
-- Name: cve cve_cve_name_key; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve
    ADD CONSTRAINT cve_cve_name_key UNIQUE (cve_name);


--
-- Name: cve cve_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve
    ADD CONSTRAINT cve_pkey PRIMARY KEY (cve_id);


--
-- Name: package package_pkg_name_key; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.package
    ADD CONSTRAINT package_pkg_name_key UNIQUE (pkg_name);


--
-- Name: release release_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (rel_id);


--
-- Name: release release_rel_name_key; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.release
    ADD CONSTRAINT release_rel_name_key UNIQUE (rel_name);


--
-- Name: repository repository_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (rep_id);


--
-- Name: repository repository_rep_name_key; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.repository
    ADD CONSTRAINT repository_rep_name_key UNIQUE (rep_name);


--
-- Name: package source_package_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.package
    ADD CONSTRAINT source_package_pkey PRIMARY KEY (pkg_id);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (st_id);


--
-- Name: urgency urgency_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.urgency
    ADD CONSTRAINT urgency_pkey PRIMARY KEY (urg_id);


--
-- Name: pkg_version version_package_pkey; Type: CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.pkg_version
    ADD CONSTRAINT version_package_pkey PRIMARY KEY (pkg_vrs_id);


--
-- Name: schema_vrs schema_vrs_pkey; Type: CONSTRAINT; Schema: maintenance; Owner: owner
--

ALTER TABLE ONLY maintenance.schema_vrs
    ADD CONSTRAINT schema_vrs_pkey PRIMARY KEY (schm_name);


--
-- Name: update_info update_info_pkey; Type: CONSTRAINT; Schema: maintenance; Owner: owner
--

ALTER TABLE ONLY maintenance.update_info
    ADD CONSTRAINT update_info_pkey PRIMARY KEY (ui_date);


--
-- Name: architecture architecture_arch_name_key; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.architecture
    ADD CONSTRAINT architecture_arch_name_key UNIQUE (arch_name);


--
-- Name: architecture architecture_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.architecture
    ADD CONSTRAINT architecture_pkey PRIMARY KEY (arch_id);


--
-- Name: assembly assembly_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assembly
    ADD CONSTRAINT assembly_pkey PRIMARY KEY (assm_id);


--
-- Name: changelog changelogs_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.changelog
    ADD CONSTRAINT changelogs_pkey PRIMARY KEY (id);


--
-- Name: package package_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.package
    ADD CONSTRAINT package_pkey PRIMARY KEY (pkg_id);


--
-- Name: package package_pkg_name_key; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.package
    ADD CONSTRAINT package_pkg_name_key UNIQUE (pkg_name);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (prj_id);


--
-- Name: release release_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (rel_id);


--
-- Name: release release_rel_name_key; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.release
    ADD CONSTRAINT release_rel_name_key UNIQUE (rel_name);


--
-- Name: urgency urgency_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.urgency
    ADD CONSTRAINT urgency_pkey PRIMARY KEY (urg_id);


--
-- Name: urgency urgency_urg_name_key; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.urgency
    ADD CONSTRAINT urgency_urg_name_key UNIQUE (urg_name);


--
-- Name: pkg_version version_package_pkey; Type: CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.pkg_version
    ADD CONSTRAINT version_package_pkey PRIMARY KEY (pkg_vrs_id);


--
-- Name: vul_cwe vul_cwe_cwe_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_cwe_id_fkey FOREIGN KEY (cwe_id) REFERENCES bdu.cwe(cwe_id) ON DELETE CASCADE;


--
-- Name: vul_cwe vul_cwe_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- Name: vul_ident vul_ident_ident_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_ident_id_fkey FOREIGN KEY (ident_id) REFERENCES bdu.identifier(ident_id) ON DELETE CASCADE;


--
-- Name: vul_ident vul_ident_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- Name: vul_sources vul_sources_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources
    ADD CONSTRAINT vul_sources_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_cve_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_cve_id_fkey FOREIGN KEY (cve_id) REFERENCES debtracker.cve(cve_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_pkg_vul_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_pkg_vul_id_fkey FOREIGN KEY (fixed_pkg_vrs_id) REFERENCES debtracker.pkg_version(pkg_vrs_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_rep_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_rep_id_fkey FOREIGN KEY (rep_id) REFERENCES debtracker.repository(rep_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_st_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_st_id_fkey FOREIGN KEY (st_id) REFERENCES debtracker.status(st_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_urg_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_urg_id_fkey FOREIGN KEY (urg_id) REFERENCES debtracker.urgency(urg_id) ON DELETE CASCADE;


--
-- Name: cve_rep cve_rep_vrs_pkg_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.cve_rep
    ADD CONSTRAINT cve_rep_vrs_pkg_id_fkey FOREIGN KEY (pkg_resolved_id) REFERENCES debtracker.pkg_version(pkg_vrs_id) ON DELETE CASCADE;


--
-- Name: repository repository_rel_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.repository
    ADD CONSTRAINT repository_rel_id_fkey FOREIGN KEY (rel_id) REFERENCES debtracker.release(rel_id) ON DELETE CASCADE;


--
-- Name: pkg_version version_package_pkg_id_fkey; Type: FK CONSTRAINT; Schema: debtracker; Owner: owner
--

ALTER TABLE ONLY debtracker.pkg_version
    ADD CONSTRAINT version_package_pkg_id_fkey FOREIGN KEY (pkg_id) REFERENCES debtracker.package(pkg_id) ON DELETE CASCADE;


--
-- Name: assembly assembly_prj_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assembly
    ADD CONSTRAINT assembly_prj_id_fkey FOREIGN KEY (prj_id) REFERENCES repositories.project(prj_id) ON DELETE CASCADE;


--
-- Name: assm_pkg_vrs assm_pkg_vrs_assm_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assm_pkg_vrs
    ADD CONSTRAINT assm_pkg_vrs_assm_id_fkey FOREIGN KEY (assm_id) REFERENCES repositories.assembly(assm_id) ON DELETE CASCADE;


--
-- Name: assm_pkg_vrs assm_pkg_vrs_pkg_vrs_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.assm_pkg_vrs
    ADD CONSTRAINT assm_pkg_vrs_pkg_vrs_id_fkey FOREIGN KEY (pkg_vrs_id) REFERENCES repositories.pkg_version(pkg_vrs_id) ON DELETE CASCADE;


--
-- Name: changelog changelog_urg_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.changelog
    ADD CONSTRAINT changelog_urg_id_fkey FOREIGN KEY (urg_id) REFERENCES repositories.urgency(urg_id);


--
-- Name: changelog changelog_vrs_pkg_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.changelog
    ADD CONSTRAINT changelog_vrs_pkg_id_fkey FOREIGN KEY (pkg_vrs_id) REFERENCES repositories.pkg_version(pkg_vrs_id) ON DELETE CASCADE;


--
-- Name: project project_arch_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.project
    ADD CONSTRAINT project_arch_id_fkey FOREIGN KEY (arch_id) REFERENCES repositories.architecture(arch_id);


--
-- Name: project project_rel_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.project
    ADD CONSTRAINT project_rel_id_fkey FOREIGN KEY (rel_id) REFERENCES repositories.release(rel_id);


--
-- Name: pkg_version version_package_pkg_id_fkey; Type: FK CONSTRAINT; Schema: repositories; Owner: owner
--

ALTER TABLE ONLY repositories.pkg_version
    ADD CONSTRAINT version_package_pkg_id_fkey FOREIGN KEY (pkg_id) REFERENCES repositories.package(pkg_id);


--
-- PostgreSQL database dump complete
--

