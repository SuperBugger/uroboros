--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bdu; Type: SCHEMA; Schema: -; Owner: owner
--

CREATE SCHEMA bdu;


ALTER SCHEMA bdu OWNER TO owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cwe; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.cwe (
    cwe_id integer NOT NULL,
    cwe_name text NOT NULL
);


ALTER TABLE bdu.cwe OWNER TO owner;

--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.cwe_cwe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.cwe_cwe_id_seq OWNER TO owner;

--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.cwe_cwe_id_seq OWNED BY bdu.cwe.cwe_id;


--
-- Name: identifier; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.identifier (
    ident_id integer NOT NULL,
    ident_type text,
    link text,
    ident_name text
);


ALTER TABLE bdu.identifier OWNER TO owner;

--
-- Name: identifier_ident_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.identifier_ident_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.identifier_ident_id_seq OWNER TO owner;

--
-- Name: identifier_ident_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.identifier_ident_id_seq OWNED BY bdu.identifier.ident_id;


--
-- Name: vul_cwe; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_cwe (
    vul_id integer NOT NULL,
    cwe_id integer NOT NULL
);


ALTER TABLE bdu.vul_cwe OWNER TO owner;

--
-- Name: vul_ident; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_ident (
    vul_id integer NOT NULL,
    ident_id integer NOT NULL
);


ALTER TABLE bdu.vul_ident OWNER TO owner;

--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vul_ident_vul_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vul_ident_vul_id_seq OWNER TO owner;

--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vul_ident_vul_id_seq OWNED BY bdu.vul_ident.vul_id;


--
-- Name: vul_sources; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vul_sources (
    vul_src_id integer NOT NULL,
    url text,
    vul_id integer
);


ALTER TABLE bdu.vul_sources OWNER TO owner;

--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vul_sources_vul_src_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vul_sources_vul_src_id_seq OWNER TO owner;

--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vul_sources_vul_src_id_seq OWNED BY bdu.vul_sources.vul_src_id;


--
-- Name: vulnerability; Type: TABLE; Schema: bdu; Owner: owner
--

CREATE TABLE bdu.vulnerability (
    vul_id integer NOT NULL,
    vul_ident text,
    vul_name text,
    vul_desc text,
    date_discovered timestamp with time zone,
    severity text,
    cvss2_vector text,
    cvss2_score text,
    cvss3_vector text,
    cvss3_score text
);


ALTER TABLE bdu.vulnerability OWNER TO owner;

--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE; Schema: bdu; Owner: owner
--

CREATE SEQUENCE bdu.vulnerability_vul_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bdu.vulnerability_vul_id_seq OWNER TO owner;

--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE OWNED BY; Schema: bdu; Owner: owner
--

ALTER SEQUENCE bdu.vulnerability_vul_id_seq OWNED BY bdu.vulnerability.vul_id;


--
-- Name: cwe cwe_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe ALTER COLUMN cwe_id SET DEFAULT nextval('bdu.cwe_cwe_id_seq'::regclass);


--
-- Name: identifier ident_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier ALTER COLUMN ident_id SET DEFAULT nextval('bdu.identifier_ident_id_seq'::regclass);


--
-- Name: vul_ident vul_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident ALTER COLUMN vul_id SET DEFAULT nextval('bdu.vul_ident_vul_id_seq'::regclass);


--
-- Name: vul_sources vul_src_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources ALTER COLUMN vul_src_id SET DEFAULT nextval('bdu.vul_sources_vul_src_id_seq'::regclass);


--
-- Name: vulnerability vul_id; Type: DEFAULT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability ALTER COLUMN vul_id SET DEFAULT nextval('bdu.vulnerability_vul_id_seq'::regclass);


--
-- Data for Name: cwe; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.cwe (cwe_id, cwe_name) FROM stdin;
\.


--
-- Data for Name: identifier; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.identifier (ident_id, ident_type, link, ident_name) FROM stdin;
\.


--
-- Data for Name: vul_cwe; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_cwe (vul_id, cwe_id) FROM stdin;
\.


--
-- Data for Name: vul_ident; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_ident (vul_id, ident_id) FROM stdin;
\.


--
-- Data for Name: vul_sources; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vul_sources (vul_src_id, url, vul_id) FROM stdin;
\.


--
-- Data for Name: vulnerability; Type: TABLE DATA; Schema: bdu; Owner: owner
--

COPY bdu.vulnerability (vul_id, vul_ident, vul_name, vul_desc, date_discovered, severity, cvss2_vector, cvss2_score, cvss3_vector, cvss3_score) FROM stdin;
\.


--
-- Name: cwe_cwe_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.cwe_cwe_id_seq', 1, false);


--
-- Name: identifier_ident_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.identifier_ident_id_seq', 1, false);


--
-- Name: vul_ident_vul_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vul_ident_vul_id_seq', 1, false);


--
-- Name: vul_sources_vul_src_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vul_sources_vul_src_id_seq', 1, false);


--
-- Name: vulnerability_vul_id_seq; Type: SEQUENCE SET; Schema: bdu; Owner: owner
--

SELECT pg_catalog.setval('bdu.vulnerability_vul_id_seq', 1, false);


--
-- Name: vul_cwe vul_cwe_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_pkey PRIMARY KEY (vul_id, cwe_id);


--
-- Name: vul_ident vul_ident_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_pkey PRIMARY KEY (vul_id, ident_id);


--
-- Name: cwe cwe_cwe_name_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe
    ADD CONSTRAINT cwe_cwe_name_key UNIQUE (cwe_name);


--
-- Name: cwe cwe_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.cwe
    ADD CONSTRAINT cwe_pkey PRIMARY KEY (cwe_id);


--
-- Name: vulnerability fstek_element_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability
    ADD CONSTRAINT fstek_element_pkey PRIMARY KEY (vul_id);


--
-- Name: identifier identifier_ident_name_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier
    ADD CONSTRAINT identifier_ident_name_key UNIQUE (ident_name);


--
-- Name: identifier identifiers_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.identifier
    ADD CONSTRAINT identifiers_pkey PRIMARY KEY (ident_id);


--
-- Name: vul_sources vul_sources_pkey; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources
    ADD CONSTRAINT vul_sources_pkey PRIMARY KEY (vul_src_id);


--
-- Name: vulnerability vulnerability_vul_ident_key; Type: CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vulnerability
    ADD CONSTRAINT vulnerability_vul_ident_key UNIQUE (vul_ident);


--
-- Name: vul_cwe vul_cwe_cwe_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_cwe_id_fkey FOREIGN KEY (cwe_id) REFERENCES bdu.cwe(cwe_id) ON DELETE CASCADE;


--
-- Name: vul_cwe vul_cwe_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_cwe
    ADD CONSTRAINT vul_cwe_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- Name: vul_ident vul_ident_ident_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_ident_id_fkey FOREIGN KEY (ident_id) REFERENCES bdu.identifier(ident_id) ON DELETE CASCADE;


--
-- Name: vul_ident vul_ident_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_ident
    ADD CONSTRAINT vul_ident_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- Name: vul_sources vul_sources_vul_id_fkey; Type: FK CONSTRAINT; Schema: bdu; Owner: owner
--

ALTER TABLE ONLY bdu.vul_sources
    ADD CONSTRAINT vul_sources_vul_id_fkey FOREIGN KEY (vul_id) REFERENCES bdu.vulnerability(vul_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

